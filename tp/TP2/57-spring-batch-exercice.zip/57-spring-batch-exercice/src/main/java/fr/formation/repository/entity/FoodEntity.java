package fr.formation.repository.entity;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Entity
@Table(name = "FOOD")
public class FoodEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String serieRef;
    private LocalDate periode;
    private Double valeur;
    private String status;
    private String unite;
    private String sujet;
    private String groupe;
    private String serie;

    public FoodEntity() {
    }

    public String getSerieRef() {
        return serieRef;
    }

    public void setSerieRef(String serieRef) {
        this.serieRef = serieRef;
    }

    public LocalDate getPeriode() {
        return periode;
    }

    public void setPeriode(LocalDate periode) {
        this.periode = periode;
    }

    public Double isValeur() {
        return valeur;
    }

    public void setValeur(Double valeur) {
        this.valeur = valeur;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUnite() {
        return unite;
    }

    public void setUnite(String unite) {
        this.unite = unite;
    }

    public String getSujet() {
        return sujet;
    }

    public void setSujet(String sujet) {
        this.sujet = sujet;
    }

    public String getGroupe() {
        return groupe;
    }

    public void setGroupe(String groupe) {
        this.groupe = groupe;
    }

    public String getSerie() {
        return serie;
    }

    public void setSerie(String serie) {
        this.serie = serie;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Food{");
        sb.append("id='").append(id).append('\'');
        sb.append(", serieRef='").append(serieRef).append('\'');
        sb.append(", periode=").append(periode.format(DateTimeFormatter.ofPattern("yyyy.MM")));
        sb.append(", valeur=").append(valeur);
        sb.append(", status='").append(status).append('\'');
        sb.append(", unite='").append(unite).append('\'');
        sb.append(", sujet='").append(sujet).append('\'');
        sb.append(", groupe='").append(groupe).append('\'');
        sb.append(", serie='").append(serie).append('\'');
        sb.append('}');
        return sb.toString();
    }

}
