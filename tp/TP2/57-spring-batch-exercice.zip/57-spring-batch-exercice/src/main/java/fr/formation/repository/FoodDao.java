package fr.formation.repository;

import fr.formation.repository.entity.FoodEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FoodDao extends JpaRepository<FoodEntity, Long> {
}
