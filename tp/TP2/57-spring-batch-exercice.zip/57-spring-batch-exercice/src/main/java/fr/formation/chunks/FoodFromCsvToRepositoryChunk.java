package fr.formation.chunks;

import fr.formation.bo.Food;
import fr.formation.repository.FoodDao;
import fr.formation.repository.entity.FoodEntity;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.data.RepositoryItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.PathResource;

import java.time.LocalDate;

//@Component
@Configuration
public class FoodFromCsvToRepositoryChunk {


    @Autowired
    private FoodDao foodDao;


    @Value("${zipped.repository}")
    private String zippedFolder;

    @Value("${unzipped.file}")
    private String unzippedFile;

    @Bean
    public FlatFileItemReader<Food> reader(){
        return new FlatFileItemReaderBuilder<Food>()
                .name("FoodItemReader")
                .resource(new PathResource(zippedFolder + "/" +unzippedFile))
                .linesToSkip(1)
                .delimited()
                .names("serieRef", "periode", "valeur","status", "unite", "sujet", "groupe", "serie")
                .fieldSetMapper(new BeanWrapperFieldSetMapper<Food>() {{
                    setTargetType(Food.class);
                }})
                .build();
    }

    @Bean
    public ItemProcessor<Food, FoodEntity> processor() {
        return f -> {
            FoodEntity fe = new FoodEntity();
            fe.setSerieRef(f.getSerieRef());
            String[] split = f.getPeriode().split("\\."); /// yyyy.MM
            fe.setPeriode(LocalDate.of(Integer.parseInt(split[0]), Integer.parseInt(split[1]), 1));
            fe.setValeur(f.getValeur());
            fe.setStatus(f.getStatus());
            fe.setUnite(f.getUnite());
            fe.setSujet(f.getSujet());
            fe.setGroupe(f.getGroupe());
            fe.setSerie(f.getSerie());
            return fe;
        };
    }

    @Bean
    public RepositoryItemWriter<FoodEntity> writer() {
        RepositoryItemWriter<FoodEntity> writer = new RepositoryItemWriter<>();
        writer.setRepository(foodDao);
        writer.setMethodName("save");
        return writer;
    }

}
