-- Insert styles
INSERT INTO styles (libelle) VALUES ('Drame');
INSERT INTO styles (libelle) VALUES ('Comédie');
INSERT INTO styles (libelle) VALUES ('Policier');
INSERT INTO styles (libelle) VALUES ('Science Fiction');
INSERT INTO styles (libelle) VALUES ('Horreur');

-- Insert films
INSERT INTO films (titre, annee_de_sortie, note_sur_10, style_id) VALUES ('Inception', 2010, 9, 4);
INSERT INTO films (titre, annee_de_sortie, note_sur_10, style_id) VALUES ('Le Parrain', 1972, 10, 1);
INSERT INTO films (titre, annee_de_sortie, note_sur_10, style_id) VALUES ('The Dark Knight', 2008, 9, 3);
INSERT INTO films (titre, annee_de_sortie, note_sur_10, style_id) VALUES ('Pulp Fiction', 1994, 9, 2);
INSERT INTO films (titre, annee_de_sortie, note_sur_10, style_id) VALUES ('Get Out', 2017, 8, 5);
