
CREATE TABLE styles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    libelle VARCHAR(255) NOT NULL
);

CREATE TABLE films (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titre VARCHAR(255) NOT NULL,
    annee_de_sortie INT NOT NULL,
    note_sur_10 INT NOT NULL,
    style_id INT,
    FOREIGN KEY (style_id) REFERENCES styles(id)
);
