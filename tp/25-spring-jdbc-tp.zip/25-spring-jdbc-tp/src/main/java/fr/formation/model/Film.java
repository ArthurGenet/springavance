package fr.formation.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class Film {
    private int id;
    private String titre;
    private int anneeDeSortie;
    private int noteSur10;
    private Style style;
}
