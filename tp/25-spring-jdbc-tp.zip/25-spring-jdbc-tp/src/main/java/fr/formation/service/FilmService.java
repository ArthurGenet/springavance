package fr.formation.service;

import fr.formation.model.Film;
import fr.formation.model.Style;
import fr.formation.repository.FilmRepository;
import fr.formation.repository.StyleRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class FilmService {

    private FilmRepository filmRepository;

    private StyleRepository styleRepository;

    public List<Film> listAll() {
        return filmRepository.findAll();
    }

    public Film findById(int id) {
        return filmRepository.findById(id);
    }

    public List<Film> findByStyle(int styleId) {
        return filmRepository.findByStyle(styleId);
    }

    public void save(Film film) {
        Optional<Style> optStyle = styleRepository.findByLibelle(film.getStyle().getLibelle());
        if (optStyle.isEmpty()) {
            styleRepository.save(film.getStyle());
            optStyle = styleRepository.findByLibelle(film.getStyle().getLibelle());
        }
        film.setStyle(optStyle.orElse(null));
        filmRepository.save(film);
    }
    public void update(Film film) {
        Optional<Style> optStyle = styleRepository.findByLibelle(film.getStyle().getLibelle());
        if (optStyle.isEmpty()) {
            styleRepository.save(film.getStyle());
            optStyle = styleRepository.findByLibelle(film.getStyle().getLibelle());
        }
        film.setStyle(optStyle.orElse(null));
        filmRepository.update(film);
    }

    public void deleteById(int id) {
        filmRepository.deleteById(id);
    }
}
