package fr.formation.service;

import fr.formation.model.Style;
import fr.formation.repository.StyleRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@AllArgsConstructor
@Service
public class StyleService {

    private StyleRepository styleRepository;

    public List<Style> listAll() {
        return styleRepository.findAll();
    }

    public Style findById(int id) {
        return styleRepository.findById(id);
    }

    public Optional<Style> findByLibelle(String libelle) {
        return styleRepository.findByLibelle(libelle);
    }

    public void save(Style style) {
        if (style != null && style.getId() == 0 && style.getLibelle() != null)
            styleRepository.save(style);
    }

    public void update(int id, Style style) {
        Style existingStyle = styleRepository.findById(id);
        if (existingStyle != null) {
            existingStyle.setLibelle(style.getLibelle());
            styleRepository.save(existingStyle);
        }
    }
}
