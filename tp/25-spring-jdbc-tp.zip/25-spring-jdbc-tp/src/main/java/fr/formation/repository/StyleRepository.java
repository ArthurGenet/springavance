package fr.formation.repository;

import fr.formation.model.Style;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@AllArgsConstructor
@Repository
public class StyleRepository {

    private JdbcTemplate jdbcTemplate;

    public List<Style> findAll() {
        String sql = "SELECT * FROM styles";
        return jdbcTemplate.query(sql, new StyleRowMapper());
    }

    public Style findById(int id) {
        String sql = "SELECT * FROM styles WHERE id = ?";
        return jdbcTemplate.queryForObject(sql, new StyleRowMapper(), id);
    }

    public Optional<Style> findByLibelle(String libelle) {
        String sql = "SELECT * FROM styles WHERE libelle = ?";
        List<Style> styles = jdbcTemplate.query(sql, new StyleRowMapper(), libelle);
        return styles.isEmpty() ? Optional.empty() : Optional.of(styles.get(0));
    }

    public void save(Style style) {
        String sql = "INSERT INTO styles (libelle) VALUES (?)";
        jdbcTemplate.update(sql, style.getLibelle());
    }

    class StyleRowMapper implements RowMapper<Style> {

        @Override
        public Style mapRow(ResultSet rs, int rowNum) throws SQLException {
            return new Style(rs.getInt("id"),
                    rs.getString("libelle"));
        }
    }
}

