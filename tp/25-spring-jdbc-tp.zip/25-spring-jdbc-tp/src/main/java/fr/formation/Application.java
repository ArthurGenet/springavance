package fr.formation;

import fr.formation.model.Film;
import fr.formation.model.Style;
import fr.formation.service.FilmService;
import fr.formation.service.StyleService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Bean
    public CommandLineRunner commandLineRunner(FilmService filmService, StyleService styleService) {
        return args -> {
            List<Style> styles = styleService.listAll();
            System.out.println("Styles:");
            styles.forEach(System.out::println);

            // Test listing all films
            List<Film> films = filmService.listAll();
            System.out.println("\nFilms:");
            films.forEach(System.out::println);

            // Test finding a film by ID
            Film filmById = filmService.findById(1);
            System.out.println("\nFilm with ID 1:");
            System.out.println(filmById);

            // Test finding films by style
            List<Film> filmsByStyle = filmService.findByStyle(styles.get(0).getId());
            System.out.println("\nFilms with style ID 1:");
            filmsByStyle.forEach(System.out::println);

            // Test adding a new film
            Style newStyle = new Style();
            newStyle.setLibelle("Action");
            Film newFilm = new Film();
            newFilm.setTitre("Mad Max: Fury Road");
            newFilm.setAnneeDeSortie(2015);
            newFilm.setNoteSur10(9);
            newFilm.setStyle(newStyle);
            filmService.save(newFilm);

            // Verify the new film was added
            films = filmService.listAll();
            System.out.println("\nFilms after adding a new film:");
            films.forEach(System.out::println);


            Film beforeUpdatedFilm = filmService.findById(1);
            System.out.println("\nBeforeUpdated film with ID 1:");
            System.out.println(beforeUpdatedFilm);

            // Test updating a film
            Film filmToUpdate = filmService.findById(1);
            filmToUpdate.setTitre("Inception Updated");
            filmToUpdate.setNoteSur10(10);
            filmToUpdate.setStyle(Style.builder().libelle("Comédie").build());
            filmService.update(filmToUpdate);

            // Verify the film was updated
            Film updatedFilm = filmService.findById(1);
            System.out.println("\nUpdated film with ID 1:");
            System.out.println(updatedFilm);

            // Test deleting a film
            filmService.deleteById(2);

            // Verify the film was deleted
            films = filmService.listAll();
            System.out.println("\nFilms after deleting a film:");
            films.forEach(System.out::println);
        };
    }



}
