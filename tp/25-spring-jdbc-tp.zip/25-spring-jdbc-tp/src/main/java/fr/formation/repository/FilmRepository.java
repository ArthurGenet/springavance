package fr.formation.repository;

import fr.formation.model.Film;
import fr.formation.model.Style;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@AllArgsConstructor
@Repository
public class  FilmRepository {

    private JdbcTemplate jdbcTemplate;

    public List<Film> findAll() {
        String sql = "SELECT f.*, s.libelle FROM films f LEFT JOIN styles s ON f.style_id = s.id";
        return jdbcTemplate.query(sql, new FilmRowMapper());
    }

    public Film findById(int id) {
        String sql = "SELECT f.*, s.libelle FROM films f LEFT JOIN styles s ON f.style_id = s.id WHERE f.id = ?";
        return jdbcTemplate.queryForObject(sql, new FilmRowMapper(), id);
    }

    public List<Film> findByStyle(int styleId) {
        String sql = "SELECT f.*, s.libelle FROM films f LEFT JOIN styles s ON f.style_id = s.id WHERE s.id = ?";
        return jdbcTemplate.query(sql, new FilmRowMapper(), styleId);
    }

    public void save(Film film) {
        String sql = "INSERT INTO films (titre, annee_de_sortie, note_sur_10, style_id) VALUES (?, ?, ?, ?)";
        jdbcTemplate.update(sql, film.getTitre(), film.getAnneeDeSortie(), film.getNoteSur10(), film.getStyle().getId());
    }

    public void update(Film film) {
        String sql = "UPDATE films SET titre = ?, annee_de_sortie = ?, note_sur_10 = ?, style_id = ? WHERE id = ?";
        jdbcTemplate.update(sql, film.getTitre(), film.getAnneeDeSortie(), film.getNoteSur10(), film.getStyle().getId(), film.getId());
    }

    public void deleteById(int id) {
        String sql = "DELETE FROM films WHERE id = ?";
        jdbcTemplate.update(sql, id);
    }


    class FilmRowMapper implements RowMapper<Film> {

        @Override
        public Film mapRow(ResultSet rs, int rowNum) throws SQLException {
            Style style = new Style(rs.getInt("style_id"),
                    rs.getString("libelle"));
            return new Film(rs.getInt("id"),
                    rs.getString("titre"),
                    rs.getInt("annee_de_sortie"),
                    rs.getInt("note_sur_10"),
                    style);
        }
    }
}
