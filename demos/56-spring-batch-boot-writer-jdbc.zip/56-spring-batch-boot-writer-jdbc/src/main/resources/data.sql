create table JF(
    annee int,
    jour varchar(20),
    libelle varchar(50)
);
