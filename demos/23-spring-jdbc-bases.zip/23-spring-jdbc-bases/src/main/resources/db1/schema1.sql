
CREATE TABLE personne (
    id int PRIMARY KEY AUTO_INCREMENT,
    nom varchar(50) NOT NULL ,
    prenom varchar(45) NOT NULL ,
    age int NOT NULL
);
