insert into personne(nom, prenom, age) values ('Legrand', 'Jack', 33);
