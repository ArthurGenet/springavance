insert into personne(nom, prenom, age) values ('Lepetit', 'Joe', 55);
