package fr.formation.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.init.DataSourceInitializer;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;

import javax.sql.DataSource;

@Configuration
public class DatabaseConfiguration {

    @Bean(name = "db1DataSource")
    @ConfigurationProperties(prefix = "spring.datasource.db1")
    public DataSource dataSource1() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "db2DataSource")
    @ConfigurationProperties(prefix = "spring.datasource.db2")
    public DataSource dataSource2() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "db1JdbcTemplate")
    public JdbcTemplate jdbcTemplate1(@Qualifier("db1DataSource") DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    @Bean(name = "db2JdbcTemplate")
    public JdbcTemplate jdbcTemplate2(@Qualifier("db2DataSource") DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    @Bean
    public DataSourceInitializer db1Initializer(@Qualifier("db1DataSource") DataSource dataSource) {
        return new DataSourceInitializer(){{
            setDataSource(dataSource);
            setDatabasePopulator( new ResourceDatabasePopulator(
                    new ClassPathResource("db1/schema1.sql"),
                    new ClassPathResource("db1/data1.sql")
            ));
        }};
    }

    @Bean
    public DataSourceInitializer db2Initializer(@Qualifier("db2DataSource") DataSource dataSource) {
        return new DataSourceInitializer(){{
            setDataSource(dataSource);
            setDatabasePopulator( new ResourceDatabasePopulator(
                    new ClassPathResource("db2/schema2.sql"),
                    new ClassPathResource("db2/data2.sql")
            ));
        }};
    }


}
