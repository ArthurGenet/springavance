package fr.formation;

import fr.formation.model.Personne;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }


    @Bean
    CommandLineRunner commandLineRunner(@Qualifier("db1JdbcTemplate") JdbcTemplate jdbcTemplate1,
                                        @Qualifier("db2JdbcTemplate") JdbcTemplate jdbcTemplate2) {
        return args -> {

            System.out.println("Liste des personne dans la base db1 :");
            jdbcTemplate1.query("select * from personne", new BeanPropertyRowMapper<>(Personne.class))
                    .forEach(System.out::println);

            System.out.println("Liste des personne dans la base db2 :");
            jdbcTemplate2.query("select * from personne", new BeanPropertyRowMapper<>(Personne.class))
                    .forEach(System.out::println);
        };
    }
}
