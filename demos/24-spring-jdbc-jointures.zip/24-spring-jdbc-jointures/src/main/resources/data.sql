
INSERT INTO personne(nom,prenom) VALUES ( 'Lebleu', 'Marie' );
INSERT INTO personne(nom,prenom) VALUES ( 'Lejaune', 'Aline' );
INSERT INTO personne(nom,prenom) VALUES ( 'Lerouge', 'Marc' );

INSERT INTO adresse (code_postal, ville, personne_id) VALUES ( '44000', 'Nantes', 1 );
INSERT INTO adresse (code_postal, ville, personne_id) VALUES ( '29000', 'Quimper', 2 );
INSERT INTO adresse (code_postal, ville, personne_id) VALUES ( '56000', 'Vannes', 3 );
