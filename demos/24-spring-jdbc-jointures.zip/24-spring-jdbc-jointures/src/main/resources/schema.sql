
CREATE TABLE personne(
  id INT AUTO_INCREMENT PRIMARY KEY ,
  nom VARCHAR(50),
  prenom VARCHAR(45)
);

CREATE TABLE ADRESSE(
    id INT AUTO_INCREMENT PRIMARY KEY ,
    code_postal VARCHAR(5),
    ville VARCHAR(100),
    personne_id INT,
    FOREIGN KEY (personne_id) REFERENCES personne(id)
);
