package fr.formation.repository;


import fr.formation.model.Adresse;
import fr.formation.model.Personne;
import lombok.AllArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

@AllArgsConstructor
@Repository
public class PersonneRepository {

    private JdbcTemplate jdbcTemplate;

    public void ajouterPersonne(Personne personne) {
        String ajoutPersonne = "INSERT INTO personne(nom,prenom) VALUES (?,?)";
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(ajoutPersonne, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, personne.getNom());
            ps.setString(2, personne.getPrenom());
            return ps;
        }, keyHolder);

        int cleGeneree = keyHolder.getKey().intValue();

        String ajoutAdresse = "INSERT INTO adresse(code_postal, ville, personne_id) VALUES (?,?,?)";
        jdbcTemplate.update(ajoutAdresse, personne.getAdresse().getCodePostal(),
                personne.getAdresse().getVille(), cleGeneree);

    }

    public List<Personne> findAll(){
        String requete = "Select p.id AS personne_id, p.nom, p.prenom, " +
                " a.id AS adresse_id, a.code_postal, a.ville" +
                " From personne p" +
                " LEFT JOIN adresse a ON a.personne_id = p.id";

        return jdbcTemplate.query(requete, new PersonneAvecAdresseRowMapper());
    }


    class PersonneAvecAdresseRowMapper implements RowMapper<Personne> {

        @Override
        public Personne mapRow(ResultSet rs, int rowNum) throws SQLException {
            Personne personne = new Personne();
            personne.setId(rs.getInt("personne_id"));
            personne.setNom(rs.getString("nom"));
            personne.setPrenom(rs.getString("prenom"));

            Adresse adresse = new Adresse();
            adresse.setId(rs.getInt("adresse_id"));
            adresse.setVille(rs.getString("ville"));
            adresse.setCodePostal(rs.getString("code_postal"));

            personne.setAdresse(adresse);
            return personne;
        }
    }

}
