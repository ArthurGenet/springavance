package fr.formation;

import fr.formation.model.Adresse;
import fr.formation.model.Personne;
import fr.formation.repository.PersonneRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.List;

@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }


    @Bean
    CommandLineRunner commandLineRunner(PersonneRepository personneRepository) {
        return args -> {
            Personne personne = Personne.builder()
                    .nom("Lechene")
                    .prenom("Suzon")
                    .adresse(
                            Adresse.builder()
                                    .codePostal("22000")
                                    .ville("Saint Brieuc")
                                    .build()
                    )
                    .build();

            personneRepository.ajouterPersonne(personne);

            List<Personne> personnes = personneRepository.findAll();
            personnes.forEach(System.out::println);
        };
    }
}
