package fr.formation;

import fr.formation.model.Tache;
import fr.formation.repository.TacheRepository;
import fr.formation.service.TacheService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

import java.time.LocalDate;
import java.util.List;

@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Bean
    CommandLineRunner commandLineRunner(TacheService tacheService) {
        return args -> {
            Tache tache = Tache.builder()
                    .libelle("Tondre la pelouse")
                    .dateLimite(LocalDate.now().plusDays(7))
                    .effectue(false)
                    .build();
            tacheService.ajouter(tache);

            tacheService.trouverTaches().forEach(System.out::println);
        };
    }

}
