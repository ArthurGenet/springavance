package fr.formation.service;

import fr.formation.exception.TacheException;
import fr.formation.model.Tache;
import fr.formation.repository.TacheRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@AllArgsConstructor
@Service
public class TacheService {

    private TacheRepository tacheRepository;

    public void ajouter(Tache tache){
        if (tache == null)
            throw new TacheException("Le tache n'existe pas");
        if (tache.getLibelle() == null || tache.getLibelle().isBlank())
            throw new TacheException("Le libelle n'existe pas");

        tacheRepository.add(tache);
    }

    public Optional<Tache> trouverTache(Integer id){
        if (id == null || id <= 0)
            throw new TacheException("Le id n'existe pas");

        return tacheRepository.findById(id);
    }

    public List<Tache> trouverTaches(){
        return tacheRepository.findAll();
    }
}
