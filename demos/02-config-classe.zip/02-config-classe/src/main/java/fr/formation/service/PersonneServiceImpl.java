package fr.formation.service;

import fr.formation.model.Personne;
import fr.formation.repository.PersonneRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PersonneServiceImpl implements PersonneService {

    private PersonneRepository personneRepository;

    @Autowired
    public PersonneServiceImpl(PersonneRepository personneRepository) {
        this.personneRepository = personneRepository;
    }

    @Override
    public void ajouter(Personne p) {
        if (p == null)
            throw new RuntimeException("p est null");

        if (p.getNom() == null)
            throw new RuntimeException("le nom est nul");

        personneRepository.save(p);
    }

    @Override
    public void modifier(Personne p) {
        personneRepository.save(p);
    }

    @Override
    public List<Personne> trouverTous() {
        return personneRepository.findAll();
    }
}
