    package fr.formation.config;


    import org.apache.commons.dbcp2.BasicDataSource;
    import org.springframework.beans.factory.annotation.Autowired;
    import org.springframework.context.annotation.Bean;
    import org.springframework.context.annotation.ComponentScan;
    import org.springframework.context.annotation.Configuration;
    import org.springframework.context.annotation.PropertySource;
    import org.springframework.core.env.Environment;
    import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
    import org.springframework.orm.jpa.JpaTransactionManager;
    import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
    import org.springframework.orm.jpa.vendor.Database;
    import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
    import org.springframework.transaction.annotation.EnableTransactionManagement;

    import javax.sql.DataSource;
    import java.util.Properties;

    @Configuration
    @ComponentScan(basePackages = {"fr.formation.service"})
    @PropertySource("classpath:datasource.properties")
    @EnableTransactionManagement
    @EnableJpaRepositories(basePackages = {"fr.formation.repository"}, entityManagerFactoryRef = "emf")
    public class OrmConfiguration {

        @Autowired
        private Environment env;

        @Bean
        public DataSource dataSource(){
            BasicDataSource bds = new BasicDataSource();
            bds.setDriverClassName(env.getProperty("driver"));
            bds.setUrl(env.getProperty("url"));
            bds.setUsername(env.getProperty("login"));
            bds.setPassword(env.getProperty("password"));
            return bds;
        }


        @Bean(name = "emf")
        LocalContainerEntityManagerFactoryBean getEmf(){
            LocalContainerEntityManagerFactoryBean emfb = new LocalContainerEntityManagerFactoryBean();
            emfb.setPackagesToScan("fr.formation.model");
            emfb.setDataSource(dataSource());

            HibernateJpaVendorAdapter adapter = new HibernateJpaVendorAdapter();
            adapter.setShowSql(false);
            adapter.setDatabase(Database.H2);
            emfb.setJpaVendorAdapter(adapter);

            Properties properties = new Properties();
            properties.put("hibernate.hbm2ddl.auto", "create");
            emfb.setJpaProperties(properties);

            return emfb;
        }

        @Bean(name = "transactionManager")
        JpaTransactionManager getTransactionManager(){
            JpaTransactionManager jtm = new JpaTransactionManager();
            jtm.setEntityManagerFactory(getEmf().getObject());

            return jtm;
        }


    }
