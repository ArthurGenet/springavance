package fr.formation.main;

import fr.formation.model.Personne;

import java.lang.reflect.Field;

public class TestPersonne {
    public static void main(String[] args) throws NoSuchFieldException, IllegalAccessException {

        Personne personne = new Personne();
        Field nom = Personne.class.getDeclaredField("nom");
        Field prenom = Personne.class.getDeclaredField("prenom");
        Field age = Personne.class.getDeclaredField("age");

        nom.setAccessible(true);
        prenom.setAccessible(true);
        age.setAccessible(true);

        nom.set(personne, "Lebleu");
        prenom.set(personne, "Suzon");
        age.set(personne, 20);

        System.out.println(personne);
    }
}
