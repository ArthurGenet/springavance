package fr.programme.bean;

import org.springframework.stereotype.Component;

@Component
public class MonBean {
    public MonBean() {
        System.out.println("Construction d'un objet MonBean");
    }
}
