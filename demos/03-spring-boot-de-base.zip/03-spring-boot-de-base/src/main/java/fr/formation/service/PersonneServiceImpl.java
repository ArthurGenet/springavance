package fr.formation.service;

import fr.formation.model.Personne;
import fr.formation.repository.PersonneRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@AllArgsConstructor
@Service
public class PersonneServiceImpl implements PersonneService {

    private final PersonneRepository personneRepository;


    @Override
    public List<Personne> trouverTous() {
        return personneRepository.findAll();
    }
}
