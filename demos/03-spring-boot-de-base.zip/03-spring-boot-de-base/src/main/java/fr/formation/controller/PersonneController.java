package fr.formation.controller;

import fr.formation.model.Personne;
import fr.formation.service.PersonneService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@AllArgsConstructor
@RestController
public class PersonneController {

   // @Autowired // -> impose Reflexion
    private PersonneService personneService;



    @GetMapping("/personnes")
    public List<Personne> getPersonnes() {
        return personneService.trouverTous();
    }

}
