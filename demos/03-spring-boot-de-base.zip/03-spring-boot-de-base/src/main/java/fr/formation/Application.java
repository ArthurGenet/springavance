package fr.formation;

import fr.formation.model.Personne;
import fr.formation.repository.PersonneRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		// java
		SpringApplication.run(Application.class, args);
		// java
	}

	@Bean
	public CommandLineRunner commandLineRunner(PersonneRepository personneRepository) {
		return args -> {
			Personne p1 = Personne.builder().nom("Legrand").prenom("Joe").build();
			Personne p2 = Personne.builder().nom("Lepetit").prenom("Jack").build();

			personneRepository.save(p1);
			personneRepository.save(p2);

			personneRepository.findAll()
					.forEach(System.out::println);

		};
	}


}
