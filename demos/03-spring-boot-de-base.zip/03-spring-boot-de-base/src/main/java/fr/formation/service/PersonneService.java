package fr.formation.service;

import fr.formation.model.Personne;

import java.util.List;

public interface PersonneService {
    List<Personne> trouverTous();
}
