package fr.formation;

import fr.formation.config.BatchConfiguration;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class BatchMain {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(BatchConfiguration.class);
        Job job = context.getBean("job2", Job.class);
        JobLauncher jobLauncher = context.getBean(JobLauncher.class);
        JobParameters jp = new JobParameters();

        try {
            jobLauncher.run(job, jp);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        context.close();
    }
}
