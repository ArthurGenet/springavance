package fr.formation.model;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class Pays {
    private String name;
    private String alpha2code;
    private String capital;
    private long population;
    private double area;
}
