package fr.formation.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder

public class Tache {
    private int id;
    private String libelle;
    private LocalDate dateLimite;
    private boolean effectue;
}
