package fr.formation.exception;

public class TacheException extends RuntimeException {
    public TacheException(String message) {
        super(message);
    }
}
