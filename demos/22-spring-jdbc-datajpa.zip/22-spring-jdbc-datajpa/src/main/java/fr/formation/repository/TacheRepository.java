package fr.formation.repository;

import fr.formation.model.Tache;

import java.util.List;
import java.util.Optional;

public interface TacheRepository {
    void add(Tache t);
    void update(Tache t);
    void delete(Integer id);
    Optional<Tache> findById(Integer id);
    List<Tache> findAll();
}
