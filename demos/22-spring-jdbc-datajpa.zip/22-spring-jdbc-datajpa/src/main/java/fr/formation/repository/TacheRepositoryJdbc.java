package fr.formation.repository;

import fr.formation.model.Tache;
import lombok.AllArgsConstructor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@AllArgsConstructor
@Repository
public class TacheRepositoryJdbc implements TacheRepository {

    private JdbcTemplate jdbcTemplate;


    @Override
    public void add(Tache t) {
        String sql = "insert into tache (libelle, date_fin, effectue) VALUES ( ?,?,? )";
        jdbcTemplate.update(sql, t.getLibelle(), t.getDateLimite(), t.isEffectue());
    }

    @Override
    public void update(Tache t) {
        String sql = "update tache set libelle=?, date_fin=?, effectue=? where id=? ";
        jdbcTemplate.update(sql, t.getLibelle(), t.getDateLimite(), t.isEffectue(), t.getId());

    }

    @Override
    public void delete(Integer id) {
        String sql = "delete from tache where id=?";
        jdbcTemplate.update(sql, id);
    }

    @Override
    public Optional<Tache> findById(Integer id) {
        String sql = "select * from tache where id=?";
        try{
            Tache trouve = jdbcTemplate.queryForObject(sql, new TacheRowMapper(), id);
            return Optional.of(trouve);
        }catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    @Override
    public List<Tache> findAll() {
        String req = "select * from tache";
        return jdbcTemplate.query(req, new TacheRowMapper());
    }


    class TacheRowMapper implements RowMapper<Tache> {
        @Override
        public Tache mapRow(ResultSet rs, int rowNum) throws SQLException {
            return Tache.builder()
                    .id(rs.getInt("id"))
                    .libelle(rs.getString("libelle"))
                    .dateLimite(rs.getDate("date_fin").toLocalDate())
                    .effectue(rs.getBoolean("effectue"))
                    .build();
        }
    }
}
