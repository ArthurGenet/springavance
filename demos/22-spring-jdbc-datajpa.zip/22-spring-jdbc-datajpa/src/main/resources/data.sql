
create table tache(
  id int AUTO_INCREMENT PRIMARY KEY ,
  libelle varchar(255),
  date_fin DATE,
  effectue BOOLEAN
);

insert into tache (libelle, date_fin, effectue) VALUES ( 'Faire les courses', '2024-06-26',FALSE );
