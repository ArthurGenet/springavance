package fr.formation.config;


import fr.formation.model.JourFerie;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

    @Autowired
    private StepBuilderFactory stepBuilderFactory;

    @Autowired
    private JobBuilderFactory  jobBuilderFactory;

    @Bean
    public ItemReader<JourFerie> reader(){
        return new FlatFileItemReaderBuilder<JourFerie>()
                .name("jfItemReader")
                .resource(new ClassPathResource("jours_feries_metropole.csv"))
                .linesToSkip(1)
                .delimited()
                .delimiter(",")
                .includedFields(0,1,3)
                .names("jour","annee","libelle")
                .fieldSetMapper(new BeanWrapperFieldSetMapper<JourFerie>() {{
                    setTargetType(JourFerie.class);
                }})
                .build();
    }

    @Bean
    public ItemProcessor<JourFerie, JourFerie> processor(){
        return jf -> {
            String libelle = null;
            switch (jf.getLibelle()){
                case "1er janvier": libelle = "Jour de l'an"; break;
                case "1er mai": libelle = "Fete du travail"; break;
                case "8 mai": libelle = "Armistice 1945"; break;
                case "14 juillet": libelle = "Fete nationale"; break;
                case "11 novembre": libelle = "Armistice 1918"; break;
                default:libelle = jf.getLibelle();
            }
            jf.setLibelle(libelle);

            return jf;
        };
    }

    @Bean
    public ItemWriter<JourFerie> writer(){
        return new FlatFileItemWriterBuilder<JourFerie>()
                .name("paysItemWriter")
                .resource(new FileSystemResource("target/jours_feries_export.csv"))
                .delimited()
                .names("jour","annee","libelle")
                .build();
    }

    @Bean
    public Step step(){
        return stepBuilderFactory
                .get("step")
                .<JourFerie,JourFerie>chunk(10)
                .reader(reader())
                .processor(processor())
                .writer(writer())
                .allowStartIfComplete(true)
                .build();
    }

    @Bean
    public Job job1(){
        return jobBuilderFactory
                .get("job1")
                .start(step())
                .build();
    }



}
