package fr.formation.config;

import fr.formation.model.Personne4;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Personne4Configuration {

    @Bean
    @ConditionalOnProperty(name = "usine", havingValue = "nantes")
    Personne4 directeurNantes(){
        return new Personne4("Lechataignier", "Aline", 63);
    }

    @Bean
    @ConditionalOnProperty(name = "usine", havingValue = "paris")
    Personne4 directeurParis(){
        return new Personne4("Lechene", "Alice", 36);
    }
}
