package fr.formation.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString

@Component
public class Personne1 {

    @Value("${p1nom}")
    private String nom;

    @Value("${p1prenom}")
    private String prenom;

    @Value("${p1age}")
    private int age;
}
