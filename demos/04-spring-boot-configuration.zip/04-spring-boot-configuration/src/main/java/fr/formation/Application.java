package fr.formation;

import fr.formation.model.Personne1;
import fr.formation.model.Personne2;
import fr.formation.model.Personne3;
import fr.formation.model.Personne4;
import fr.formation.model.Personne5;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Application {

	@Value("${annee.courante}")
	private Integer anneeCourante;

	@Autowired
	private Personne1 p1;

	@Autowired
	private Personne2 p2;

	@Autowired
	@Qualifier("aine")
	private Personne3 p3aine;

	@Autowired
	@Qualifier("cadet")
	private Personne3 p3cadet;

	@Autowired
	private Personne3 benjamin;

	@Autowired
	private Personne4 directeur;

	@Autowired
	private Personne5 p5;

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Bean
	CommandLineRunner commandLineRunner() {
		return args -> {
			System.out.println("Année courante : " + anneeCourante);
			System.out.println("p1 = " + p1);
			System.out.println("p2 = " + p2);
			System.out.println("p3aine = " + p3aine);
			System.out.println("p3cadet = " + p3cadet);
			System.out.println("benjamin = " + benjamin);
			System.out.println("directeur = " + directeur);
			System.out.println("p5 = " + p5);
		};
	}

}
