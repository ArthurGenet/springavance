package fr.formation.config;

import fr.formation.model.Personne5;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile("dev")
//@Profile(value = "!default")
public class Personne5DevConfiguration {

    @Bean
    Personne5 p5(){
        return new Personne5("p5dev", "Joe", 30);
    }
}
