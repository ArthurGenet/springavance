package fr.formation.config;

import fr.formation.model.Personne5;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile("default")
public class Personne5DefaultConfiguration {

    @Bean
    Personne5 p5(){
        return new Personne5("p5default", "Joe", 30);
    }
}
