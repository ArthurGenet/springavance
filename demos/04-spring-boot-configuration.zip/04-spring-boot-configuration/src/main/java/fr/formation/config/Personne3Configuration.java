package fr.formation.config;


import fr.formation.model.Personne3;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Personne3Configuration {

    @Bean("aine")
    Personne3 personne3() {
        return new Personne3("Lebleu", "Joe", 88);
    }

    @Bean
    Personne3 cadet() {
        return new Personne3("Lejaune", "Jack", 77);
    }

    @Bean
    Personne3 benjamin() {
        return new Personne3("Lerouge", "Will", 66);
    }
}
