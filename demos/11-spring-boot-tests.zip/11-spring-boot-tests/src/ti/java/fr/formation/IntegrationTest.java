package fr.formation;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class IntegrationTest {
}
