package fr.formation.spring.bll;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import fr.formation.spring.dal.PersonneDao;
import fr.formation.spring.entity.Personne;

@Service
public class PersonneManager {

	@Autowired
	PersonneDao pDao;

	@Value(value = "${annee}")
	private Integer annee;

	public void ajout(Personne p) throws Exception {
		if (p == null)
			throw new Exception("Personne nul");
		pDao.save(p);
	}

	public Personne trouver(int id) {
		Optional<Personne> trouveOpt = pDao.findById(id);
		if (trouveOpt.isPresent())
			return trouveOpt.get();
		else
			return null;
	}

	
	public List<Personne> liste() {
		return pDao.findAll();
	}

	

	public Integer getAnnee() {
		return annee;
	}


	
	public static String getApplicationName() {
		return "My App";
	}
	
	
}
