package fr.formation.spring.bll;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import fr.formation.spring.dal.PersonneDao;
import fr.formation.spring.entity.Personne;
import org.springframework.test.annotation.DirtiesContext;


@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
@SpringBootTest(classes = {PersonneManager.class})
public class PersonneManagerSpringUnitTest {

	@MockBean
	private PersonneDao pDao;
	
	@Autowired
	private PersonneManager personneManager;
	
	@Captor
	private ArgumentCaptor<Personne> captor;
	
	
	@Test
	void testAjoutPersonneNulle() throws Exception {
		Exception e = assertThrows(Exception.class, () -> personneManager.ajout(null));
		assertEquals("Personne nul", e.getMessage());
	}
	
	@Test
	void testAjoutPersonne() {
		Personne p = new Personne();
		assertDoesNotThrow(() -> personneManager.ajout(p));
		Mockito.verify(pDao).save(captor.capture());
		assertSame(p, captor.getValue());
	}
	
	@Test
	void testTrouvePersonneExistante() {
		Personne p = new Personne();
		Optional<Personne> optPers = Optional.of(p);
		Mockito.when(pDao.findById(Mockito.anyInt())).thenReturn(optPers);
		
		Personne trouve = personneManager.trouver(5);
		assertAll(
				() -> assertNotNull(trouve),
				() -> assertSame(p, trouve)
				);
	}
	
	@Test
	void testTrouvePersonneInexistante() {
		Mockito.when(pDao.findById(Mockito.anyInt())).thenReturn(Optional.empty());
		
		Personne trouve = personneManager.trouver(5);
		assertNull(trouve);
	}
	
	@Test
	void testListe() {
		List<Personne> listeP = new ArrayList<>();
		listeP.add(new Personne(1, "Legrand", "Joe", 44));
		listeP.add(new Personne(2, "Lepetit", "Jack", 55));
		
		Mockito.when(pDao.findAll()).thenReturn(listeP);
		
		assertSame(listeP, personneManager.liste());
	}

	@Test
	void testGetAnnee() {

		assertEquals(2022, personneManager.getAnnee());
	}
	
	
	@Test
	void testGetApplicationName() {
		
		assertEquals("My App", PersonneManager.getApplicationName());
		
		// Comment stubber la méthode static
		MockedStatic<PersonneManager> pm = Mockito.mockStatic(PersonneManager.class);
		pm.when(() -> PersonneManager.getApplicationName()).thenReturn("My other App");
		
		assertEquals("My other App", PersonneManager.getApplicationName());
	}
	
	
}
