package fr.formation.spring.dal;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.jdbc.Sql;

import fr.formation.spring.entity.Personne;

@DataJpaTest
public class PersonneDaoIntegrationTest {

	@Autowired
	PersonneDao pDao;

	@Test
	@Sql("/createUser.sql")
	public void testListe() {
		List<Personne> liste = pDao.trouverTous();

		assertEquals(5, liste.size());
	}

	@Test
	@Sql("/createUser.sql")
	public void testTrouverParNom() {
		List<Personne> liste = pDao.trouverParNom("Legrand");

		assertEquals(2, liste.size());
	}

	// Ne devrait pas exister
	@Test
	public void testAjout() {
		Personne p = new Personne("Leblond", "Luc", 41);

		pDao.save(p);

		List<Personne> liste = pDao.findAll();

		assertAll(() -> assertEquals(4, liste.size()), () -> assertTrue(liste.get(3).getId() > 0),
				() -> assertEquals("Leblond", liste.get(3).getNom()),
				() -> assertEquals("Luc", liste.get(3).getPrenom()), () -> assertEquals(41, liste.get(3).getAge()));
	}

}
