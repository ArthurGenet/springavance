package fr.formation.spring.rest;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import fr.formation.spring.bll.PersonneManager;
import fr.formation.spring.entity.Personne;

@ExtendWith(MockitoExtension.class)
public class PersonneRestControllerUnitTest {

	@InjectMocks
	private PersonneRestController controller;
	
	@Mock
	private PersonneManager pm;
	
	
	@Test
	void testGetPersonnePasTrouvee() {
		Mockito.when(pm.trouver(Mockito.anyInt())).thenReturn(null);
		
		ResponseEntity<Personne> re = controller.getPersonne(5);
		assertTrue(re.getStatusCode().is4xxClientError());
	}
	
	@Test
	void testGetPersonneTrouvee() {

		Personne p = new Personne("Lepetit", "Joe", 44);
		Mockito.when(pm.trouver(Mockito.anyInt())).thenReturn(p);
		
		ResponseEntity<Personne> re = controller.getPersonne(5);
		assertEquals(p, re.getBody());
		assertTrue(re.getStatusCode().is2xxSuccessful());
	}

}
