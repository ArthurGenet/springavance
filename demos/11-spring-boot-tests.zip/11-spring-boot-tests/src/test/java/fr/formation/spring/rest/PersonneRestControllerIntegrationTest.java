package fr.formation.spring.rest;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import fr.formation.spring.bll.PersonneManager;
import fr.formation.spring.entity.Personne;


@WebMvcTest(controllers = PersonneRestController.class)
public class PersonneRestControllerIntegrationTest {

	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private PersonneManager pm;
	
	
	@Test
	void testGetPersonnePasTrouvee() throws Exception {
		Mockito.when(pm.trouver(Mockito.anyInt())).thenReturn(null);
		mockMvc
			.perform(get("/rs/5"))
			.andExpect(status().is4xxClientError());
		
	}
	
	@Test
	void testGetPersonneTrouvee() throws Exception {

		Personne p = new Personne("Lepetit", "Joe", 44);
		Mockito.when(pm.trouver(Mockito.anyInt())).thenReturn(p);
		
		mockMvc
			.perform(get("/rs/5"))
			.andExpect(status().isOk())
			.andExpect(content().string(containsString("Lepetit")));
	}

}
