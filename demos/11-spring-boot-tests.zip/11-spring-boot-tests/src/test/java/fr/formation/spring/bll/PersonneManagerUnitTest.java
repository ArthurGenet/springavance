package fr.formation.spring.bll;


import fr.formation.spring.dal.PersonneDao;
import fr.formation.spring.entity.Personne;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Optional;

@ExtendWith(MockitoExtension.class)
public class PersonneManagerUnitTest {

    @Mock
    private PersonneDao daoMock;

    @InjectMocks
    private PersonneManager manager;

    @Captor
    private ArgumentCaptor<Personne> captor;

    @Test
    void testAjoutNull(){
        Exception e = Assertions.assertThrows(Exception.class, () -> manager.ajout(null));
        Assertions.assertEquals("Personne nul", e.getMessage());
    }

    @Test
    void testAjoutPersonneNonNul()  {
        Personne p = new Personne("A", "B", 44);
        Assertions.assertDoesNotThrow(() -> manager.ajout(p));

        Mockito.verify(daoMock).save(captor.capture());
        Assertions.assertSame(p, captor.getValue());
    }

    @Test
    void testTrouverPasDeData(){
        Mockito.when(daoMock.findById(Mockito.anyInt())).thenReturn(Optional.empty());
        Personne trouve = manager.trouver(41);
        Assert.assertNull(trouve);
    }

    @Test
    void testTrouverAvecData(){
        Personne p = new Personne("A", "B", 44);
        Mockito.when(daoMock.findById(Mockito.anyInt())).thenReturn(Optional.of(p));
        Personne trouve = manager.trouver(41);
        Assert.assertNotNull(trouve);
        Assertions.assertSame(p, trouve);
    }

    @Test
    void testGetValue(){
        ReflectionTestUtils.setField(manager, "annee", 2023);
        int annee = manager.getAnnee();
        Assertions.assertEquals(2023, annee);
    }

}
