
insert into livre (titre, auteur, nb_pages) values ('Les fleurs du mal', 'Baudelaire', 354);
insert into livre (titre, auteur, nb_pages) values ('La peste', 'Camus', 289);
