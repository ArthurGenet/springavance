
create table livre(
   id int auto_increment primary key ,
    titre varchar(50) not null,
    auteur varchar(45) not null,
    nb_pages int not null
) ;
