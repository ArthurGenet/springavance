package fr.formation;

import fr.formation.model.Livre;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Bean
    public CommandLineRunner commandLineRunner(JdbcTemplate jdbcTemplate) {
        return args -> {
            List<Livre> livres = jdbcTemplate.query("select * from livre", new BeanPropertyRowMapper<>(Livre.class));
            System.out.println("\nListe des livres en BDD");
            livres.forEach(System.out::println);

            List<String> titres = jdbcTemplate.queryForList("select l.titre from livre l", String.class);
            System.out.println("\nListe des titres en BDD");
            titres.forEach(System.out::println);

            int nbLivres = jdbcTemplate.queryForObject("select count(id) from livre", Integer.class);
            System.out.println("\nNombres de livres :" + nbLivres);

            jdbcTemplate.update("insert into livre (titre, auteur, nb_pages) values (?,?,?)",
                    "San-Antonio chez les gones", "Frederic Dare", 222);


            livres = jdbcTemplate.query("select * from livre", new BeanPropertyRowMapper<>(Livre.class));
            System.out.println("\nListe des livres en BDD apres insertion");
            livres.forEach(System.out::println);

            // Recherche d'un element par son id
            Livre trouve = jdbcTemplate.queryForObject("Select * from livre where id = ?",
                    new LivreRowMapper(), 2);
            System.out.println("Livre dont l'id est 2 : " + trouve);

            // Recherche d'un element par son id
            try {
                trouve = jdbcTemplate.queryForObject("Select * from livre where id = ?",
                        new BeanPropertyRowMapper<>(Livre.class), 17);
                System.out.println("Livre dont l'id est 17 : " + trouve);
            } catch (EmptyResultDataAccessException e) {
                System.out.println("Livre dont l'id est 17 : aucun");
            }

        };
    }


    private static class LivreRowMapper implements RowMapper<Livre> {
        @Override
        public Livre mapRow(ResultSet rs, int rowNum) throws SQLException {
            return Livre.builder()
                    .id(rs.getInt("id"))
                    .titre(rs.getString("titre"))
                    .auteur(rs.getString("auteur"))
                    .nbPages(rs.getInt("nb_pages"))
                    .build();
        }
    }

}
