package fr.formation.main;

import fr.formation.model.Adresse;
import fr.formation.model.Personne;
import fr.formation.service.PersonneService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

public class TestOrmService {
    public static void main(String[] args) {
        ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");

        PersonneService ps = ac.getBean(PersonneService.class);

        Personne p1 = new Personne("Legrand", "Joe", new Adresse("44000", "Nantes"));
        Personne p2 = new Personne("Lepetit", "Aline", new Adresse("56000", "Vannes"));
        Personne p3 = new Personne("Lemoyen", "Jack", new Adresse("35000", "Rennes"));
        Personne p4 = new Personne("Leblond", "Ludo", new Adresse("22000", "Saint Brieuc"));

        ps.ajouter(p1);
        ps.ajouter(p2);
        ps.ajouter(p3);
        ps.ajouter(p4);

        List<Personne> listeP = ps.trouverTous();
        System.out.println("Liste des personnes en base : ");
        listeP.forEach(System.out::println);

    }
}
