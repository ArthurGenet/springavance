package fr.formation.service;

import fr.formation.model.Personne;

import java.util.List;

public interface PersonneService {

    void ajouter(Personne p);
    void modifier(Personne p);
    List<Personne> trouverTous();
}
