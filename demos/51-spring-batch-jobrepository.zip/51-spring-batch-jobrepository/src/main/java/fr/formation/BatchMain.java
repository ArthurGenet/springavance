package fr.formation;

import fr.formation.config.BatchConfiguration;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.HashMap;
import java.util.Map;

public class BatchMain {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(BatchConfiguration.class);
        Job job = context.getBean("job2", Job.class);
        JobLauncher jobLauncher = context.getBean(JobLauncher.class);
        Map<String, JobParameter> map = new HashMap<>();
        map.put("time", new JobParameter(System.nanoTime()));
        JobParameters jp = new JobParameters(map);

        try {
            jobLauncher.run(job, jp);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        context.close();
    }
}
