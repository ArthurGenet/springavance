package fr.formation.config;


import fr.formation.model.Pays;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;

@Configuration
@EnableBatchProcessing
@Import(value = BddConfiguration.class)
public class BatchConfiguration {

    @Autowired
    private StepBuilderFactory stepBuilderFactory;

    @Autowired
    private JobBuilderFactory  jobBuilderFactory;

    @Bean
    public ItemReader<Pays> reader(){
        return new FlatFileItemReaderBuilder<Pays>()
                .name("paysItemReader")
                .resource(new ClassPathResource("pays_init.csv"))
                .delimited()
                .names("alpha2code","area","capital","name","population")
                .fieldSetMapper(new BeanWrapperFieldSetMapper<Pays>() {{
                    setTargetType(Pays.class);
                }})
                .build();
    }

    @Bean
    public ItemProcessor<Pays, Pays> processor(){
        return pays -> {
            pays.setName(pays.getName().toUpperCase());
            pays.setCapital(pays.getCapital().toUpperCase());
            return pays;
        };
    }

    @Bean
    public ItemWriter<Pays> writer(){
        return new FlatFileItemWriterBuilder<Pays>()
                .name("paysItemWriter")
                .resource(new FileSystemResource("target/pays_export.csv"))
                .delimited()
                .names("alpha2code","area","capital","name","population")
                .build();
    }

    @Bean
    public Step step(){
        return stepBuilderFactory
                .get("step")
                .<Pays,Pays>chunk(10)
                .reader(reader())
                .processor(processor())
                .writer(writer())
                .allowStartIfComplete(true)
                .build();
    }

    @Bean(name = "job1")
    public Job job1(){
        return jobBuilderFactory
                .get("job1")
                .start(step())
                .build();
    }

    @Bean
    public Job job2(){
        return jobBuilderFactory
                .get("job2")
                .start(step())
                .build();
    }

}
