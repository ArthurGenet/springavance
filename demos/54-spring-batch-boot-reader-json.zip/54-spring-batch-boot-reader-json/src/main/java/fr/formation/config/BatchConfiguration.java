package fr.formation.config;


import fr.formation.model.Pays;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.batch.item.json.JacksonJsonObjectReader;
import org.springframework.batch.item.json.builder.JsonItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

    @Autowired
    private StepBuilderFactory stepBuilderFactory;

    @Autowired
    private JobBuilderFactory  jobBuilderFactory;


    @Bean
    public ItemReader<Pays> reader(){
        return new JsonItemReaderBuilder<Pays>()
                .name("jfItemReader")
                .resource(new ClassPathResource("pays.json"))
                .jsonObjectReader(new JacksonJsonObjectReader<>(Pays.class))
                .build();
    }

    @Bean
    public ItemProcessor<Pays, Pays> processor(){
        return pays -> {
            pays.setCapital(pays.getCapital() ==null ? "" : pays.getCapital().toUpperCase());
            pays.setName(pays.getName()== null ? "" : pays.getName().toUpperCase());
            return pays;
        };
    }

    @Bean
    public ItemWriter<Pays> writer(){
        return new FlatFileItemWriterBuilder<Pays>()
                .name("paysItemWriter")
                .resource(new FileSystemResource("target/pays_export.csv"))
                .delimited()
                .names("alpha2Code", "area", "capital", "name", "population")
                .build();
    }

    @Bean
    public Step step(){
        return stepBuilderFactory
                .get("step")
                .<Pays, Pays>chunk(10)
                .reader(reader())
                .processor(processor())
                .writer(writer())
                .allowStartIfComplete(true)
                .build();
    }

    @Bean
    public Job job1(){
        return jobBuilderFactory
                .get("job1")
                .start(step())
                .build();
    }



}
