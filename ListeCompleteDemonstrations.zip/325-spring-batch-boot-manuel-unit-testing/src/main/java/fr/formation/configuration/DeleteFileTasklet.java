package fr.formation.configuration;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;

import java.io.File;

@Component
public class DeleteFileTasklet implements Tasklet{

    @Value("${repository}")
    private String folder;

    @Value("${file}")
    private String file;


    @Override
    public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {
        System.out.println("Tentative de suppression du fichier dezippé");
        System.out.println(folder + "/" + file);
        File sourceFile = ResourceUtils.getFile(folder + "/" + file);
        if (!sourceFile.delete()) {
            throw new RuntimeException();
        }
        return RepeatStatus.FINISHED;
    }
}
