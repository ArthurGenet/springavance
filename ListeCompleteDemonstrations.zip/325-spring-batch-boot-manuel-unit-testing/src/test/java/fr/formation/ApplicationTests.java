	package fr.formation;

	import fr.formation.configuration.BatchConfiguration;
	import org.junit.jupiter.api.Assertions;
	import org.junit.jupiter.api.Test;
	import org.junit.jupiter.api.extension.ExtendWith;
	import org.springframework.batch.core.*;
	import org.springframework.batch.test.AssertFile;
	import org.springframework.batch.test.JobLauncherTestUtils;
	import org.springframework.batch.test.context.SpringBatchTest;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
	import org.springframework.core.io.FileSystemResource;
	import org.springframework.test.context.ContextConfiguration;
	import org.springframework.test.context.junit.jupiter.SpringExtension;

	@SuppressWarnings("all")

	@ExtendWith(SpringExtension.class)
	@EnableAutoConfiguration
	@ContextConfiguration(classes = {BatchConfiguration.class})
	@SpringBatchTest()
	public class ApplicationTests {


		@Autowired
		private JobLauncherTestUtils jobLauncherTestUtils;

		private JobParameters defaultJobParameters() {
			JobParametersBuilder paramsBuilder = new JobParametersBuilder();
			return paramsBuilder.toJobParameters();
		}


		@Test
		public void testJobPays() throws Exception {
			FileSystemResource expectedResult = new FileSystemResource("src/test/resources/pays-expected.csv");
			FileSystemResource actualResult = new FileSystemResource("target/pays.csv");

			JobExecution jobExecution = jobLauncherTestUtils.launchJob(defaultJobParameters());
			JobInstance actualJobInstance = jobExecution.getJobInstance();
			ExitStatus actualJobExitStatus = jobExecution.getExitStatus();

			Assertions.assertEquals(actualJobInstance.getJobName(), "paysjob");
			Assertions.assertEquals(actualJobExitStatus.getExitCode(), "COMPLETED");
			AssertFile.assertFileEquals(expectedResult, actualResult);
		}

		@Test
		public void testStepPays() throws Exception {
			JobExecution jobExecution = jobLauncherTestUtils.launchStep("step");
			Assertions.assertEquals(new ExitStatus("COMPLETED").getExitCode() ,
					jobExecution.getExitStatus().getExitCode());

		}

	}
