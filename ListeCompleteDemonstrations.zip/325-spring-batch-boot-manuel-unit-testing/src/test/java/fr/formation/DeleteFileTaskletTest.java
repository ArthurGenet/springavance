    package fr.formation;


    import fr.formation.configuration.DeleteFileTasklet;
    import org.junit.jupiter.api.Assertions;
    import org.junit.jupiter.api.Test;
    import org.springframework.batch.core.StepContribution;
    import org.springframework.batch.core.StepExecution;
    import org.springframework.batch.core.scope.context.ChunkContext;
    import org.springframework.batch.core.scope.context.StepContext;
    import org.springframework.batch.repeat.RepeatStatus;
    import org.springframework.batch.test.MetaDataInstanceFactory;
    import org.springframework.test.util.ReflectionTestUtils;


    public class DeleteFileTaskletTest {
        @Test
        void testDelete() throws Exception {
            StepExecution stepExecution = MetaDataInstanceFactory.createStepExecution();
            StepContribution contribution = new StepContribution(stepExecution);
            ChunkContext context = new ChunkContext(
                    new StepContext(stepExecution)
            );
            DeleteFileTasklet deleteFileTasklet = new DeleteFileTasklet();
            ReflectionTestUtils.setField(deleteFileTasklet, "folder", "src/test/resources/zipped");
            ReflectionTestUtils.setField(deleteFileTasklet, "file", "data.zip");
            Assertions.assertEquals(RepeatStatus.FINISHED, deleteFileTasklet.execute(contribution , context));
        }

        @Test
        void testDeleteException() throws Exception {
            StepExecution stepExecution = MetaDataInstanceFactory.createStepExecution();
            StepContribution contribution = new StepContribution(stepExecution);
            ChunkContext context = new ChunkContext(
                    new StepContext(stepExecution)
            );
            DeleteFileTasklet deleteFileTasklet = new DeleteFileTasklet();
            ReflectionTestUtils.setField(deleteFileTasklet, "folder", "src/main/resources/zipped");
            ReflectionTestUtils.setField(deleteFileTasklet, "file", "data.csv");
            Assertions.assertThrows(RuntimeException.class, () -> deleteFileTasklet.execute(contribution , context));
        }
    }
