package fr.formation.configuration;


import fr.formation.configuration.model.Pays;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

    @Autowired
    private JobBuilderFactory jobBuilderFactory;

    @Autowired
    private StepBuilderFactory stepBuilderFactory;


    @Bean
    public FlatFileItemReader<Pays> reader() {
        System.out.println("reader ...");
        return new FlatFileItemReaderBuilder<Pays>()
                .name("paysItemReader")
                .resource(new ClassPathResource("pays_init.csv"))
                .delimited()
                .names("alpha2Code", "area", "capital", "name", "population")
                .fieldSetMapper(new BeanWrapperFieldSetMapper<Pays>() {{
                    setTargetType(Pays.class);
                }})
                .build();
    }

    @Bean
    public ItemProcessor<Pays, Pays> processor() {
        return pays -> {
            pays.setName(pays.getName().toUpperCase());
            pays.setCapital(pays.getCapital().toUpperCase());
            return pays;
        };
    }

    @Bean
    public FlatFileItemWriter<Pays> writer() {
        return new FlatFileItemWriterBuilder<Pays>()
                .name("paysItemWriter")
                .resource(new FileSystemResource("target/pays.csv"))
                .delimited()
                .names(new String[]{"alpha2Code", "area", "capital", "name", "population"})
                .build();
    }


    @Bean
    public Step step() {
        return stepBuilderFactory.get("step")
                .<Pays, Pays>chunk(10)
                .reader(reader())
                .processor(processor())
                .writer(writer())
//                .allowStartIfComplete(true)
                .build();
    }

    @Bean
    public Job job() {
        return jobBuilderFactory.get("job")
                .start(step())
                .build();
    }
}
