package fr.formation.configuration;


import fr.formation.configuration.model.JourFerie;
import fr.formation.validator.ParameterValidator;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.lang.Nullable;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;


    @Bean
    @StepScope
    public FlatFileItemReader<JourFerie> reader(@Value("#{jobParameters['inputFile']}") String inputFile){
        return new FlatFileItemReaderBuilder<JourFerie>()
                .name("jourFerieItemReader")
                .resource(new FileSystemResource(inputFile))
                .linesToSkip(1)
                .delimited()
                .includedFields(new Integer[] {0, 1, 3})
                .names("jour", "annee", "libelle")
                .fieldSetMapper(new BeanWrapperFieldSetMapper<JourFerie>() {{
                    setTargetType(JourFerie.class);
                }})
                .build();
    }

    @Bean
    public ItemProcessor<JourFerie, JourFerie> processor() {
        return jourFerie -> {
            String libelle = null;
            switch (jourFerie.getLibelle()){
                case "1er janvier" : libelle = "Jour de l'An"; break;
                case "1er mai" : libelle = "Fête du Travail"; break;
                case "8 mai" : libelle = "Armistice 1945"; break;
                case "14 juillet" : libelle = "Fête Nationale"; break;
                case "11 novembre" : libelle = "Armistice 1918"; break;
                default: libelle = jourFerie.getLibelle();
            }

            return new JourFerie(jourFerie.getAnnee(), jourFerie.getJour(), libelle);
        };
    }

    @Bean
    @StepScope
    public FlatFileItemWriter<JourFerie> writer(@Value("#{jobParameters['outputFile']}") String sortie){
        return new FlatFileItemWriterBuilder<JourFerie>()
                .name("jourFerieItemWriter")
                .resource(new FileSystemResource(sortie))
                .delimited()
                .names(new String[]{"jour", "annee", "libelle"})
                .build();

    }

    @Bean
    public Job importJourFerieJob() {
        return jobBuilderFactory.get("importJourFerieJob")
                .start(step1())
                .validator(new ParameterValidator())
                .build();
    }


    @Bean
    public Step step1() {
        return stepBuilderFactory.get("step1")
                .<JourFerie, JourFerie> chunk(10)
                .reader(reader(null))
                .processor(processor())
                .writer(writer(null))
                .build();
    }

}
