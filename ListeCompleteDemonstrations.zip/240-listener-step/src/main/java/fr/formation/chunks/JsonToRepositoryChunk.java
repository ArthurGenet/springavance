package fr.formation.chunks;

import fr.formation.bo.Pays;
import fr.formation.repository.PaysDao;
import fr.formation.repository.entity.PaysEntity;
import org.springframework.batch.core.ChunkListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.data.RepositoryItemWriter;
import org.springframework.batch.item.json.JacksonJsonObjectReader;
import org.springframework.batch.item.json.JsonItemReader;
import org.springframework.batch.item.json.builder.JsonItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.PathResource;
import org.springframework.stereotype.Component;


import java.net.MalformedURLException;

@Component
public class JsonToRepositoryChunk{


    @Autowired
    private PaysDao paysDao;


    @Value("${zipped.repository}")
    private String zippedFolder;

    @Value("${unzipped.file}")
    private String unzippedFile;
    @Bean
    public JsonItemReader<Pays> reader() throws MalformedURLException {
        return new JsonItemReaderBuilder<Pays>()
                .name("paysItemReader")
                .resource(new PathResource(zippedFolder + "/" +unzippedFile))
                .jsonObjectReader(new JacksonJsonObjectReader<>(Pays.class))
                .build();
    }
    @Bean
    public ItemProcessor<Pays, PaysEntity> processor() {
        return pays -> {
            PaysEntity pe = new PaysEntity();
            pe.setCapitale(pays.getCapital());
            pe.setCode(pays.getAlpha2Code());
            pe.setNom(pays.getName());
            pe.setPopulation(pays.getPopulation());
            pe.setSuperficie(pays.getArea());
            return pe;
        };
    }

    @Bean
    public RepositoryItemWriter<PaysEntity> writer() {
        RepositoryItemWriter<PaysEntity> writer = new RepositoryItemWriter<>();
        writer.setRepository(paysDao);
        writer.setMethodName("save");
        return writer;
    }

}
