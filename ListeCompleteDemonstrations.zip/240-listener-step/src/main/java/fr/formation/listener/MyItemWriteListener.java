package fr.formation.listener;

import fr.formation.repository.entity.PaysEntity;
import org.springframework.batch.core.ItemWriteListener;

import java.util.List;

public class MyItemWriteListener implements ItemWriteListener<PaysEntity> {
    @Override
    public void beforeWrite(List items) {
        System.out.println("  beforeWrite : " + items.size());
    }

    @Override
    public void afterWrite(List items) {
        System.out.println("  afterWrite : " + items.size());
    }

    @Override
    public void onWriteError(Exception exception, List items) {
        System.out.println("  onWriteError : " + exception.getMessage());
    }
}


