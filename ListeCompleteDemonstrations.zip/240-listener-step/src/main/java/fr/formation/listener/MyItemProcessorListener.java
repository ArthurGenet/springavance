package fr.formation.listener;

import fr.formation.bo.Pays;
import fr.formation.repository.entity.PaysEntity;
import org.springframework.batch.core.ItemProcessListener;

public class MyItemProcessorListener implements ItemProcessListener<Pays, PaysEntity> {
    @Override
    public void beforeProcess(Pays item) {
        System.out.println("    beforeProcess : " + item);
    }

    @Override
    public void afterProcess(Pays item, PaysEntity result) {
        System.out.println("    afterProcess : " + result);
    }

    @Override
    public void onProcessError(Pays item, Exception e) {
        System.out.println("    onProcessError : " + e.getMessage());
    }
}
