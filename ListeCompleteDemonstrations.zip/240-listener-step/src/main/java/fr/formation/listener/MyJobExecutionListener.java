    package fr.formation.listener;

    import org.springframework.batch.core.JobExecution;
    import org.springframework.batch.core.JobExecutionListener;
    import org.springframework.batch.core.StepExecution;

    import java.util.Collection;

    public class MyJobExecutionListener implements JobExecutionListener {
        @Override
        public void beforeJob(JobExecution jobExecution) {
            System.out.println("beforeJob : ");
            System.out.println("Status = " + jobExecution.getStatus());
            System.out.println("JobName() = " + jobExecution.getJobInstance().getJobName());
            Collection<StepExecution> stepsEx = jobExecution.getStepExecutions();
            System.out.println("StepExecutions = " + stepsEx.size());
            stepsEx.forEach(s -> System.out.println("   - " + s.getStepName()));
        }

        @Override
        public void afterJob(JobExecution jobExecution) {
            System.out.println("afterJob : ");
            System.out.println("Status = " + jobExecution.getStatus());
            System.out.println("JobName() = " + jobExecution.getJobInstance().getJobName());
            Collection<StepExecution> stepsEx = jobExecution.getStepExecutions();
            System.out.println("StepExecutions = " + stepsEx.size());
            stepsEx.forEach(s -> System.out.println("   - " + s.getStepName()));

        }
    }


