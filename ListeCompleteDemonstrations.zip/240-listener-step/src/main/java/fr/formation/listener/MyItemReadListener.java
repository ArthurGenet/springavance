package fr.formation.listener;

import fr.formation.bo.Pays;
import org.springframework.batch.core.ItemReadListener;

public class MyItemReadListener implements ItemReadListener<Pays> {
    @Override
    public void beforeRead() {
        System.out.println("  beforeRead");
    }

    @Override
    public void afterRead(Pays item) {
        System.out.println("  afterRead : " + item);
    }

    @Override
    public void onReadError(Exception ex) {
        System.out.println("  onReadError : " + ex.getMessage());
    }
}
