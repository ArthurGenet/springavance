    package fr.formation.listener;

    import org.springframework.batch.core.ExitStatus;
    import org.springframework.batch.core.StepExecution;
    import org.springframework.batch.core.StepExecutionListener;

    public class MyStepExecutionListener implements StepExecutionListener {
        @Override
        public void beforeStep(StepExecution stepExecution) {
            System.out.println("beforeStep 1");
        }

        @Override
        public ExitStatus afterStep(StepExecution stepExecution) {
            System.out.println("afterStep 1");
            return stepExecution.getExitStatus();
        }
    }
