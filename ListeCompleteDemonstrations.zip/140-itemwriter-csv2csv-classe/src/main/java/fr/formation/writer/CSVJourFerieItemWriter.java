    package fr.formation.writer;

    import fr.formation.model.JourFerie;
    import org.springframework.batch.item.file.FlatFileItemWriter;
    import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
    import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
    import org.springframework.core.io.FileSystemResource;
    @SuppressWarnings("all")

    public class CSVJourFerieItemWriter extends FlatFileItemWriter<JourFerie> {

        public CSVJourFerieItemWriter() {
            setName("jourFerieItemWriter");
            setResource(new FileSystemResource("target/jours_feries_metropole-sortie.csv"));
            setHeaderCallback(writer -> writer.write("date;annee;nom_jour_ferie"));
            setAppendAllowed(false);
            setLineAggregator(new JourFerieLineAggregator());
        }

        private class JourFerieLineAggregator extends DelimitedLineAggregator<JourFerie> {
            public JourFerieLineAggregator() {
                setDelimiter(";");
                setFieldExtractor(new BeanWrapperFieldExtractor<JourFerie>() {
                    {
                        setNames(new String[]{"jour", "annee", "libelle"});
                    }
                });
            }
        }

    }
