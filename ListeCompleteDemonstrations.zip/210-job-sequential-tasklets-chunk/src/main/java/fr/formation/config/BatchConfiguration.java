package fr.formation.config;


import fr.formation.bo.Pays;
import fr.formation.repository.PaysDao;
import fr.formation.repository.entity.PaysEntity;
import fr.formation.tasklets.DeleteUnzipFileTasklet;
import fr.formation.tasklets.ListRepositoryDataTasklet;
import fr.formation.tasklets.UnzipTasklet;
import fr.formation.util.MyZipFile;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.data.RepositoryItemWriter;
import org.springframework.batch.item.json.JacksonJsonObjectReader;
import org.springframework.batch.item.json.JsonItemReader;
import org.springframework.batch.item.json.builder.JsonItemReaderBuilder;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.PathResource;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.net.MalformedURLException;
import java.util.List;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

    @Autowired
    private JobBuilderFactory jobBuilderFactory;

    @Autowired
    private StepBuilderFactory stepBuilderFactory;

    @Autowired
    JsonItemReader<Pays> reader;

    @Autowired
    ItemProcessor<Pays, PaysEntity> processor;

    @Autowired
    RepositoryItemWriter<PaysEntity> writer;

    @Autowired
    UnzipTasklet unzipTasklet;

    @Autowired
    DeleteUnzipFileTasklet deleteUnzipFileTasklet;

    @Autowired
    ListRepositoryDataTasklet listRepositoryDataTasklet;

    @Bean
    public Step unzipStep(){
        return stepBuilderFactory.get("unzipTasklet")
                .tasklet(unzipTasklet)
                .build();
    }

    @Bean
    public Step transfertToRepositoryStep() throws MalformedURLException {
        return stepBuilderFactory.get("chunkTransfertToRepository")
                .<Pays, PaysEntity> chunk(10)
                .reader(reader)
                .processor(processor)
                .writer(writer)
                .build();
    }


    @Bean
    public Step deleteUnzipFileStep(){
        return stepBuilderFactory.get("deleteUnzipFileTasklet")
                .tasklet(deleteUnzipFileTasklet)
                .build();
    }
    @Bean
    public Step listRepositoryDataStep(){
        return stepBuilderFactory.get("listRepositoryDataTasklet")
                .tasklet(listRepositoryDataTasklet)
                .build();
    }

    @Bean
    public Job myJob() throws MalformedURLException {
        return jobBuilderFactory.get("MyJob")
                .start(unzipStep())
                .next(transfertToRepositoryStep())
                .next(deleteUnzipFileStep())
                .next(listRepositoryDataStep())
                .build();
    }



}
