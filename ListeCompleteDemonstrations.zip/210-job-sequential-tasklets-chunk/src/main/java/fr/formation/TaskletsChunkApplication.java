package fr.formation;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@SpringBootApplication
public class TaskletsChunkApplication implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(TaskletsChunkApplication.class, args);
    }


    @Autowired
    private JobLauncher jobLauncher;

    @Autowired
    private Job job;

    @Override
    public void run(String... args) throws Exception {
        LocalDateTime date = LocalDateTime.now();
        jobLauncher
                .run(job, new JobParametersBuilder()
                        .addString("launchDateTime", DateTimeFormatter.ofPattern("dd/MM/yyyy - HH:mm:ss").format(date))
                        .toJobParameters());
    }


}
