package fr.formation.tasklets;

import fr.formation.util.MyZipFile;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;

import java.io.File;

@Component
public class DeleteUnzipFileTasklet implements Tasklet{

    @Value("${zipped.repository}")
    private String zippedFolder;

    @Value("${unzipped.file}")
    private String unzippedFile;

    @Override
    public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {
        System.out.println("Tentative de suppression du fichier dezippé");
        File sourceFile = ResourceUtils.getFile(zippedFolder + "/" +unzippedFile);
        if (sourceFile.delete()) {
            System.out.println("Fichier supprimé");
        }
        else {
            System.out.println("Erreur lors de la suppression du fichier");
        }
        return RepeatStatus.FINISHED;
    }
}
