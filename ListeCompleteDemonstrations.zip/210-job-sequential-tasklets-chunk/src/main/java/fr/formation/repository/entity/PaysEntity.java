package fr.formation.repository.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class PaysEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String nom;
    private String code;
    private String capitale;
    private long population;
    private double superficie;

    public PaysEntity() {
    }

    public PaysEntity(String nom, String code, String capitale, long population, double superficie) {
        this.nom = nom;
        this.code = code;
        this.capitale = capitale;
        this.population = population;
        this.superficie = superficie;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCapitale() {
        return capitale;
    }

    public void setCapitale(String capitale) {
        this.capitale = capitale;
    }

    public long getPopulation() {
        return population;
    }

    public void setPopulation(long population) {
        this.population = population;
    }

    public double getSuperficie() {
        return superficie;
    }

    public void setSuperficie(double superficie) {
        this.superficie = superficie;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("PaysEntity{");
        sb.append("id=").append(id);
        sb.append(", nom='").append(nom).append('\'');
        sb.append(", code='").append(code).append('\'');
        sb.append(", capitale='").append(capitale).append('\'');
        sb.append(", population=").append(population);
        sb.append(", superficie=").append(superficie);
        sb.append('}');
        return sb.toString();
    }
}
