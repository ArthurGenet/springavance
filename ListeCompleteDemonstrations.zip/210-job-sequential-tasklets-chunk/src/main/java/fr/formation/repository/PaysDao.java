package fr.formation.repository;

import fr.formation.repository.entity.PaysEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaysDao extends JpaRepository<PaysEntity, Long> {
}
