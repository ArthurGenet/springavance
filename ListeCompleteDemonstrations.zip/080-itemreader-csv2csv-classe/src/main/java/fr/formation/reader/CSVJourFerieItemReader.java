package fr.formation.reader;

import fr.formation.configuration.model.JourFerie;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.core.io.ClassPathResource;

import java.time.Year;

public class CSVJourFerieItemReader extends FlatFileItemReader<JourFerie> {

    public CSVJourFerieItemReader() {
        setName("jourFerieItemReader");
        setResource(new ClassPathResource("jours_feries_metropole.csv"));
        setLinesToSkip(1);
        setLineMapper(lineMapper());
    }

    private LineMapper<JourFerie> lineMapper() {

        final DefaultLineMapper<JourFerie> defaultLineMapper = new DefaultLineMapper<>();
        final DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
        lineTokenizer.setDelimiter(",");
        lineTokenizer.setStrict(false);
        lineTokenizer.setIncludedFields(0, 1, 3);
        lineTokenizer.setNames("jour", "annee", "libelle");
        defaultLineMapper.setLineTokenizer(lineTokenizer);
        defaultLineMapper.setFieldSetMapper(new BeanWrapperFieldSetMapper<JourFerie>(){{
            setTargetType(JourFerie.class);
        }});

        return defaultLineMapper;
    }

/*
    private LineMapper<JourFerie> lineMapper() {
        final DefaultLineMapper<JourFerie> defaultLineMapper = new DefaultLineMapper<>();
        final DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
        lineTokenizer.setDelimiter(",");
        lineTokenizer.setStrict(false);
        defaultLineMapper.setLineTokenizer(lineTokenizer);

        final JourFerieFieldSetMapper fieldSetMapper = new JourFerieFieldSetMapper();
        defaultLineMapper.setFieldSetMapper(fieldSetMapper);

        return defaultLineMapper;
    }


    private class JourFerieFieldSetMapper implements FieldSetMapper<JourFerie> {
        @Override
        public JourFerie mapFieldSet(FieldSet fieldSet) {
            int annee = Integer.parseInt(fieldSet.readString(1));
            Year year = Year.of(annee);
            JourFerie jf = new JourFerie(year, fieldSet.readString(0), fieldSet.readString(3));
            return jf;
        }
    }
*/

}
