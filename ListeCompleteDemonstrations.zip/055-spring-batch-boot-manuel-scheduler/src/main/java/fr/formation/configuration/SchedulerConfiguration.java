package fr.formation.configuration;


import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Date;

    @Configuration
    @EnableScheduling
    public class SchedulerConfiguration {
        @Autowired
        private JobLauncher jobLauncher;
        @Autowired
        private Job job;

        @Scheduled(fixedRate = 2000, initialDelay = 10000)
        public void launchJob() throws Exception {
            LocalDateTime date = LocalDateTime.now();
            JobExecution jobExecution = jobLauncher
                    .run(job, new JobParametersBuilder()
                            .addString("launchDateTime", DateTimeFormatter.ofPattern("dd/MM/yyyy - HH:mm:ss").format(date))
                            .addDate("launchDate", Date.from(date.toInstant(ZoneOffset.UTC)))
                            .toJobParameters());
            System.out.println(jobExecution.getStatus());
        }
    }



