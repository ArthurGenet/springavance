package fr.formation.config;


import fr.formation.bo.Pays;
import fr.formation.repository.PaysDao;
import fr.formation.repository.entity.PaysEntity;
import fr.formation.tasklet.VerifyDataTasklet;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.data.RepositoryItemWriter;
import org.springframework.batch.item.json.JacksonJsonObjectReader;
import org.springframework.batch.item.json.JsonItemReader;
import org.springframework.batch.item.json.builder.JsonItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;

import java.io.IOException;
import java.net.MalformedURLException;

@Configuration
@EnableBatchProcessing
public class PaysConfiguration {

    @Bean
    @StepScope
    public JsonItemReader<Pays> reader(@Value("#{stepExecutionContext[fileName]}") String filename) throws MalformedURLException {
        return new JsonItemReaderBuilder<Pays>()
                .name("paysItemReader")
                .resource(new ClassPathResource(filename))
                .jsonObjectReader(new JacksonJsonObjectReader<>(Pays.class))

                .build();
    }

    @Bean
    public ItemProcessor<Pays, PaysEntity> processor() {
        return pays -> {
            PaysEntity pe = new PaysEntity();
            pe.setCapitale(pays.getCapital());
            pe.setCode(pays.getAlpha2Code());
            pe.setNom(pays.getName());
            pe.setPopulation(pays.getPopulation());
            pe.setSuperficie(pays.getArea());
            return pe;
        };
    }

    @Autowired
    private PaysDao paysDao;

    @Bean
    public RepositoryItemWriter<PaysEntity> writer() {
        RepositoryItemWriter<PaysEntity> writer = new RepositoryItemWriter<>();
        writer.setRepository(paysDao);
        writer.setMethodName("save");
        return writer;
    }


    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;


    // Utilisé en mode multithread
    @Bean
    public TaskExecutor taskExecutor() {
        return new SimpleAsyncTaskExecutor("spring_batch");
    }

    @Bean
    public Job importJourFeriePartitionnerJob() throws MalformedURLException {
        return jobBuilderFactory.get("paysPartitioningJob")
                .start(partitionStep())
                .next(step2())
                .build();
    }

    @Autowired
    public MyResourcePartitioner partitioner;

    @Bean
    public Step partitionStep() throws MalformedURLException {
        return stepBuilderFactory.get("partitionStep")
                .partitioner("slaveStep", partitioner)
                .step(slaveStep())
                .taskExecutor(taskExecutor())
                .build();
    }


    @Bean
    public Step slaveStep() throws MalformedURLException {
        return stepBuilderFactory.get("slaveStep")
                .<Pays, PaysEntity> chunk(1)
                .reader(reader(null))
                .processor(processor())
                .writer(writer())
                .build();
    }


    @Autowired
    private VerifyDataTasklet verifyDataTasklet;


    @Bean
    public Step step2(){
        return stepBuilderFactory.get("step2")
                .tasklet(verifyDataTasklet)
                .build();
    }


}
