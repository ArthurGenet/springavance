    package fr.formation.config;

    import org.springframework.batch.core.partition.support.Partitioner;
    import org.springframework.batch.item.ExecutionContext;
    import org.springframework.beans.factory.annotation.Autowired;
    import org.springframework.core.io.Resource;
    import org.springframework.core.io.support.ResourcePatternResolver;
    import org.springframework.stereotype.Component;

    import java.io.IOException;
    import java.util.HashMap;
    import java.util.Map;

    @Component
    public class MyResourcePartitioner implements Partitioner {

        @Autowired
        ResourcePatternResolver resolver;

        @Override
        public Map<String, ExecutionContext> partition(int gridSize) {
            Map<String, ExecutionContext> map = new HashMap<String, ExecutionContext>(gridSize);
            try {
                Resource[] resources = resolver.getResources("file:src/main/resources/*.json");
                int i = 0;
                for (Resource resource : resources) {
                    ExecutionContext context = new ExecutionContext();
                    context.putString("fileName", resource.getFilename());
                    map.put("partition" + i++, context);
                }
            } catch (IOException e) {
                throw new RuntimeException("pas de fichier JSON");
            }
            return map;
        }
    }
