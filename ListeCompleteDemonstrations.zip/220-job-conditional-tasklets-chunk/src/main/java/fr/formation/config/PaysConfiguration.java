package fr.formation.config;


import fr.formation.bo.Pays;
import fr.formation.repository.PaysDao;
import fr.formation.repository.entity.PaysEntity;
import fr.formation.tasklet.VerifyDataTasklet;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.data.RepositoryItemWriter;
import org.springframework.batch.item.json.JacksonJsonObjectReader;
import org.springframework.batch.item.json.JsonItemReader;
import org.springframework.batch.item.json.builder.JsonItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import java.net.MalformedURLException;

@Configuration
@EnableBatchProcessing
public class PaysConfiguration {

    @Bean
    public JsonItemReader<Pays> reader1() {
        return new JsonItemReaderBuilder<Pays>()
                .name("paysItemReader")
                .resource(new ClassPathResource("pays0.json"))
                .jsonObjectReader(new JacksonJsonObjectReader<>(Pays.class))

                .build();
    }

    @Bean
    public JsonItemReader<Pays> reader2() {
        return new JsonItemReaderBuilder<Pays>()
                .name("paysItemReader")
                .resource(new ClassPathResource("pays1.json"))
                .jsonObjectReader(new JacksonJsonObjectReader<>(Pays.class))

                .build();
    }

    @Bean
    public JsonItemReader<Pays> reader3()  {
        return new JsonItemReaderBuilder<Pays>()
                .name("paysItemReader")
                .resource(new ClassPathResource("pays2.json"))
                .jsonObjectReader(new JacksonJsonObjectReader<>(Pays.class))

                .build();
    }

    @Bean
    public ItemProcessor<Pays, PaysEntity> processor() {
        return pays -> {
            PaysEntity pe = new PaysEntity();
            pe.setCapitale(pays.getCapital());
            pe.setCode(pays.getAlpha2Code());
            pe.setNom(pays.getName());
            pe.setPopulation(pays.getPopulation());
            pe.setSuperficie(pays.getArea());
            return pe;
        };
    }

    @Autowired
    private PaysDao paysDao;

    @Bean
    public RepositoryItemWriter<PaysEntity> writer() {
        RepositoryItemWriter<PaysEntity> writer = new RepositoryItemWriter<>();
        writer.setRepository(paysDao);
        writer.setMethodName("save");
        return writer;
    }


    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;

    @Bean
    public Job importJourFerieJob() throws MalformedURLException {
        return jobBuilderFactory.get("paysJob")
                .start(step11())
                .on("COMPLETED").to(step2())
                .from(step11()).on("FAILED").to(step12())
                .from(step12()).on("COMPLETED").to(step2())
                .from(step12()).on("FAILED").to(step13())
                .from(step13()).on("COMPLETED").to(step2())
                .end()
                .build();
    }


    @Bean
    public Step step11() throws MalformedURLException {
        return stepBuilderFactory.get("step11")
                .<Pays, PaysEntity> chunk(10)
                .reader(reader1())
                .processor(processor())
                .writer(writer())
                .build();
    }

    @Bean
    public Step step12() throws MalformedURLException {
        return stepBuilderFactory.get("step12")
                .<Pays, PaysEntity> chunk(10)
                .reader(reader2())
                .processor(processor())
                .writer(writer())
                .build();
    }

    @Bean
    public Step step13() throws MalformedURLException {
        return stepBuilderFactory.get("step13")
                .<Pays, PaysEntity> chunk(10)
                .reader(reader3())
                .processor(processor())
                .writer(writer())
                .build();
    }


    @Autowired
    private VerifyDataTasklet verifyDataTasklet;


    @Bean
    public Step step2(){
        return stepBuilderFactory.get("step2")
                .tasklet(verifyDataTasklet)
                .build();
    }

}
