package fr.formation.config;


import fr.formation.bo.Pays;
import fr.formation.exception.PopulationException;
import fr.formation.exception.ServiceException;
import fr.formation.exception.SuperficieException;
import fr.formation.repository.PaysDao;
import fr.formation.repository.entity.PaysEntity;
import fr.formation.tasklet.VerifyDataTasklet;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.data.RepositoryItemWriter;
import org.springframework.batch.item.json.JacksonJsonObjectReader;
import org.springframework.batch.item.json.JsonItemReader;
import org.springframework.batch.item.json.builder.JsonItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.retry.RetryPolicy;
import org.springframework.retry.policy.ExceptionClassifierRetryPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;

import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

@Configuration
@EnableBatchProcessing
public class PaysConfiguration {

    @Bean
    public JsonItemReader<Pays> reader() throws MalformedURLException {
        return new JsonItemReaderBuilder<Pays>()
                .name("paysItemReader")
                .resource(new ClassPathResource("pays.json"))
                .jsonObjectReader(new JacksonJsonObjectReader<>(Pays.class))

                .build();
    }
/*
    @Bean
    public ItemProcessor<Pays, PaysEntity> processor() throws ServiceException {
        return pays -> {

            if (pays.getArea() <= 0) {
                System.out.println("PB Area : " + pays);
                if (new Random().nextBoolean())
                    pays.setArea(1);
                throw new SuperficieException(pays.getArea(), "Superficie négative");
            }
            if (pays.getPopulation() <= 0){
                System.out.println("PB Population : " + pays);
                pays.setPopulation(1);
                throw new PopulationException(pays.getPopulation(), "Population négative");
            }
            if (pays.getName() == null || pays.getName().isBlank()){
                pays.setName("none");
                System.out.println("PB : " + pays);
                throw new ServiceException("Nom obligatoire");
            }


            PaysEntity pe = new PaysEntity();
            pe.setCapitale(pays.getCapital());
            pe.setCode(pays.getAlpha2Code());
            pe.setNom(pays.getName());
            pe.setPopulation(pays.getPopulation());
            pe.setSuperficie(pays.getArea());


            return pe;
        };
    }

 */
@Bean
public ItemProcessor<Pays, PaysEntity> processor() throws ServiceException {
    return pays -> {

        if (new Random().nextInt(15) == 0){
            System.out.println("Erreur : " + pays);
            throw new ServiceException("Erreur : " + pays);
        }

        PaysEntity pe = new PaysEntity();
        pe.setCapitale(pays.getCapital());
        pe.setCode(pays.getAlpha2Code());
        pe.setNom(pays.getName());
        pe.setPopulation(pays.getPopulation());
        pe.setSuperficie(pays.getArea());


        return pe;
    };
}

    @Autowired
    private PaysDao paysDao;

    @Bean
    public RepositoryItemWriter<PaysEntity> writer() {
        RepositoryItemWriter<PaysEntity> writer = new RepositoryItemWriter<>();
        writer.setRepository(paysDao);
        writer.setMethodName("save");
        return writer;
    }


    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;

    @Bean
    public Job importJourFerieJob() throws MalformedURLException, ServiceException {
        return jobBuilderFactory.get("paysJob")
                .start(step1())
                .next(step2())
                .build();
    }


    @Bean
    public Step step1() throws MalformedURLException, ServiceException {
        return stepBuilderFactory.get("step1")
                .<Pays, PaysEntity> chunk(10)
                .reader(reader())
                .processor(processor())
                .writer(writer())
                .faultTolerant()
                .retryPolicy(specificRetryPolicy())
                .build();
    }

    @Bean
    public ExceptionClassifierRetryPolicy specificRetryPolicy() {

        Map<Class<? extends Throwable>, RetryPolicy> policyMap = new HashMap<>();
        policyMap.put(PopulationException.class, new SimpleRetryPolicy(4));
        policyMap.put(SuperficieException.class, new SimpleRetryPolicy(5));
        policyMap.put(ServiceException.class, new SimpleRetryPolicy(3));

        ExceptionClassifierRetryPolicy retryPolicy = new ExceptionClassifierRetryPolicy();
        retryPolicy.setPolicyMap(policyMap);
        return retryPolicy;
    }

    @Autowired
    private VerifyDataTasklet verifyDataTasklet;


    @Bean
    public Step step2(){
        return stepBuilderFactory.get("step2")
                .tasklet(verifyDataTasklet)
                .build();
    }

}
