package fr.formation.exception;

public class SuperficieException extends Exception {
    private Double superficie;
    public SuperficieException(Double superficie, String message) {
        super(message);
        this.superficie = superficie;
    }

    public Double getSuperficie() {
        return superficie;
    }
}
