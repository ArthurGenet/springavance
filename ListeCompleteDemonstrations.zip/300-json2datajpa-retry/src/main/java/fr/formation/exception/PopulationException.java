package fr.formation.exception;

public class PopulationException extends Exception {
    private Long population;
    public PopulationException(Long population, String message) {
        super(message);
        this.population = population;
    }

    public Long getPopulation() {
        return population;
    }
}
