package fr.formation.configuration;


import fr.formation.model.Pays;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.xml.StaxEventItemWriter;
import org.springframework.batch.item.xml.builder.StaxEventItemWriterBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;


    @Bean
    public FlatFileItemReader<Pays> reader(){
        return new FlatFileItemReaderBuilder<Pays>()
                .name("paysItemReader")
                .resource(new ClassPathResource("pays_init.csv"))
                .linesToSkip(1)
                .delimited()
                .names("alpha2Code","area","capital","name","population")
                .fieldSetMapper(new BeanWrapperFieldSetMapper<Pays>() {{
                    setTargetType(Pays.class);
                }})
                .build();
    }

    @Bean
    public ItemProcessor<Pays, Pays> processor() {
        return pays -> pays;
    }

    @Bean
    public StaxEventItemWriter<Pays> writer() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setClassesToBeBound(Pays.class);
        return new StaxEventItemWriterBuilder<Pays>()
                .name("paysItemWriter")
                .rootTagName("liste")
                .marshaller(marshaller)
                .resource(new FileSystemResource("target/pays.xml"))
                .overwriteOutput(true)
                .build();
    }

    @Bean
    public Job importJourFerieJob() {
        return jobBuilderFactory.get("importJourFerieJob")
                .start(step1())
                .build();
    }


    @Bean
    public Step step1() {
        return stepBuilderFactory.get("step1")
                .<Pays, Pays> chunk(10)
                .reader(reader())
                .processor(processor())
                .writer(writer())
                .build();
    }
}
