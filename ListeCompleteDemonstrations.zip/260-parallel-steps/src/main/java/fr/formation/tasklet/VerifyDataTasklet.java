package fr.formation.tasklet;

import fr.formation.repository.PaysDao;
import fr.formation.repository.entity.PaysEntity;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class VerifyDataTasklet implements Tasklet {

    @Autowired
    private PaysDao paysDao;

    @Override
    public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {
        List<PaysEntity> listePays = paysDao.findAll();
        listePays.forEach(p -> System.out.println(p));
        return null;
    }
}
