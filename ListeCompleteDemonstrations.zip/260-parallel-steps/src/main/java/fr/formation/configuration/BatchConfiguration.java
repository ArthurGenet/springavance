package fr.formation.configuration;


import fr.formation.listener.MyChunkListener;
import fr.formation.model.JourFerie;
import fr.formation.model.Pays;
import fr.formation.repository.PaysDao;
import fr.formation.repository.entity.PaysEntity;
import fr.formation.tasklet.VerifyDataTasklet;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.job.builder.FlowBuilder;
import org.springframework.batch.core.job.flow.Flow;
import org.springframework.batch.core.job.flow.support.SimpleFlow;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.data.RepositoryItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.json.JacksonJsonObjectReader;
import org.springframework.batch.item.json.JsonItemReader;
import org.springframework.batch.item.json.builder.JsonItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.net.MalformedURLException;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;

                // STEP 1
    @Bean
    public FlatFileItemReader<JourFerie> reader1(){
        return new FlatFileItemReaderBuilder<JourFerie>()
                .name("jourFerieItemReader")
                .resource(new ClassPathResource("jours_feries_metropole.csv"))
                .linesToSkip(1)
                .delimited()
                .includedFields(new Integer[] {0, 1, 3})
                .names(new String[]{"jour", "annee", "libelle"})
                .fieldSetMapper(new BeanWrapperFieldSetMapper<JourFerie>() {{
                    setTargetType(JourFerie.class);
                }})
                .build();
    }

    @Bean
    public ItemProcessor<JourFerie, JourFerie> processor1() {
        return jourFerie -> {
            String libelle = null;
            switch (jourFerie.getLibelle()){
                case "1er janvier" : libelle = "Jour de l'An"; break;
                case "1er mai" : libelle = "Fête du Travail"; break;
                case "8 mai" : libelle = "Armistice 1945"; break;
                case "14 juillet" : libelle = "Fête Nationale"; break;
                case "11 novembre" : libelle = "Armistice 1918"; break;
                default: libelle = jourFerie.getLibelle();
            }

            return new JourFerie(jourFerie.getAnnee(), jourFerie.getJour(), libelle);
        };
    }
    @Bean
    public FlatFileItemWriter<JourFerie> writer1(){
        return new FlatFileItemWriterBuilder<JourFerie>()
                .name("jourFerieItemWriter")
                .resource(new FileSystemResource("target/jours_feries_metropole-sortie.csv"))
                .headerCallback(writer -> writer.write("date;annee;nom_jour_ferie"))
                .append(false)

                .delimited()
                .delimiter(";")
                .names(new String[]{"jour", "annee", "libelle"})
                .build();

    }


    @Bean
    public Step joursFeriesStep() {
        return stepBuilderFactory.get("step1")
                .<JourFerie, JourFerie> chunk(3)
                .reader(reader1())
                .processor(processor1())
                .writer(writer1())
                .listener(new MyChunkListener())
                .build();
    }


    // STEP 2
    @Bean
    public JsonItemReader<Pays> reader() throws MalformedURLException {
        return new JsonItemReaderBuilder<Pays>()
                .name("paysItemReader")
                .resource(new ClassPathResource("pays.json"))
                .jsonObjectReader(new JacksonJsonObjectReader<>(Pays.class))

                .build();
    }

    @Bean
    public ItemProcessor<Pays, PaysEntity> processor() {
        return pays -> {
            PaysEntity pe = new PaysEntity();
            pe.setCapitale(pays.getCapital());
            pe.setCode(pays.getAlpha2Code());
            pe.setNom(pays.getName());
            pe.setPopulation(pays.getPopulation());
            pe.setSuperficie(pays.getArea());
            return pe;
        };
    }

    @Autowired
    private PaysDao paysDao;

    @Bean
    public RepositoryItemWriter<PaysEntity> writer() {
        RepositoryItemWriter<PaysEntity> writer = new RepositoryItemWriter<>();
        writer.setRepository(paysDao);
        writer.setMethodName("save");
        return writer;
    }


    @Bean
    public Step paysStep() throws MalformedURLException {
        return stepBuilderFactory.get("step2")
                .<Pays, PaysEntity> chunk(3)
                .reader(reader())
                .processor(processor())
                .writer(writer())
                .listener(new MyChunkListener())
                .build();
    }


    // STEP 3 : Après STEP 2

    @Autowired
    private VerifyDataTasklet verifyDataTasklet;


    @Bean
    public Step verifierPaysStep(){
        return stepBuilderFactory.get("step3")
                .tasklet(verifyDataTasklet)
                .build();
    }


    // JOB

    @Bean
    public TaskExecutor taskExecutor() {
        return new SimpleAsyncTaskExecutor("spring_batch");
    }

    @Bean
    public Flow splitFlow() throws MalformedURLException {
        return new FlowBuilder<SimpleFlow>("splitFlow")
                .split(taskExecutor())
                .add(joursFeriesFlow(), paysFlow())
                .build();
    }

    private Flow joursFeriesFlow() {
        return new FlowBuilder<SimpleFlow>("joursFeriesFlow")
                .start(joursFeriesStep())
                .build();
    }

    private Flow paysFlow() throws MalformedURLException {
        return new FlowBuilder<SimpleFlow>("paysFlow")
                .start(paysStep())
                .next(verifierPaysStep())
                .build();
    }

    @Bean
    public Job importJourFerieJob() throws MalformedURLException {
        return jobBuilderFactory.get("jourFerieEtPaysJob")
                .start(splitFlow())
                .build()
                .build();
    }



}
