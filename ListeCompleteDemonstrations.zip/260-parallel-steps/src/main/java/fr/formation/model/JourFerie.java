package fr.formation.model;

import java.time.LocalDate;
import java.time.Year;

public class JourFerie {

    private String annee;
    private String jour;
    private String libelle;

    public JourFerie() {
    }

    public JourFerie(String annee, String jour, String libelle) {
        this.annee = annee;
        this.jour = jour;
        this.libelle = libelle;
    }

    public String getAnnee() {
        return annee;
    }

    public void setAnnee(String annee) {
        this.annee = annee;
    }

    public String getJour() {
        return jour;
    }

    public void setJour(String jour) {
        this.jour = jour;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("JourFerie{");
        sb.append("annee=").append(annee);
        sb.append(", jour=").append(jour);
        sb.append(", libelle='").append(libelle).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
