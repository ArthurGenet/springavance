package fr.formation;

import fr.formation.config.SpringConfig;
import org.springframework.batch.core.*;
import org.springframework.batch.core.explore.support.JobExplorerFactoryBean;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import javax.sql.DataSource;
import java.time.LocalDateTime;
import java.util.*;

public class Lancement {
    public static void main(String[] args) {

        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
        JobLauncher jobLauncher = (JobLauncher) context.getBean(JobLauncher.class);
        Job job = context.getBean(Job.class);

        System.out.println("Starting the batch job");
        try {


            Map<String,JobParameter> parameters = new HashMap<>();
            parameters.put("time",new JobParameter(System.nanoTime()));
            JobParameters jobParameters = new JobParameters(parameters);

            JobExecution jobExecution = jobLauncher.run(job, jobParameters);
        //  JobExecution jobExecution = jobLauncher.run(job, new JobParameters());


            Collection<StepExecution> stepExecutions = jobExecution.getStepExecutions();
            stepExecutions.forEach(stepE ->
                    System.out.println("Step '" + stepE.getStepName() + "' Status : " + stepE.getStatus()));

            System.out.println("Job '" + jobExecution.getJobInstance().getJobName() + "' Status : " + jobExecution.getStatus());
        } catch (Exception e) {
            System.out.println("Job failed : " + e.getMessage());
        }
        context.close();
    }

}
