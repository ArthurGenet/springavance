package fr.formation.configuration;


import fr.formation.configuration.model.Pays;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.batch.item.json.JacksonJsonObjectReader;
import org.springframework.batch.item.json.JsonItemReader;
import org.springframework.batch.item.json.builder.JsonItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;


    @Bean
    public JsonItemReader<Pays> reader() {
        return new JsonItemReaderBuilder<Pays>()
                .name("paysItemReader")
                .resource(new ClassPathResource("pays.json"))
                .jsonObjectReader(new JacksonJsonObjectReader<>(Pays.class))

                .build();
    }

    @Bean
    public ItemProcessor<Pays, Pays> processor() {
        return pays -> {
            pays.setCapital(pays.getCapital() == null ? "" : pays.getCapital().toUpperCase());
            pays.setName(pays.getName() == null ? "" : pays.getName().toUpperCase());

            return pays;
        };
    }
    @Bean
    public FlatFileItemWriter<Pays> writer(){
        return new FlatFileItemWriterBuilder<Pays>()
                .name("paysItemWriter")
                .resource(new FileSystemResource("target/pays-sortie.csv"))
                .delimited()
                .names(new String[]{"alpha2Code", "area", "capital", "name", "population"})
                .build();

    }

    @Bean
    public Job importPaysJob() {
        return jobBuilderFactory.get("importPaysJob")
                .start(step1())
                .build();
    }


    @Bean
    public Step step1() {
        return stepBuilderFactory.get("step1")
                .<Pays, Pays> chunk(10)
                .reader(reader())
                .processor(processor())
                .writer(writer())
                .build();
    }
}
