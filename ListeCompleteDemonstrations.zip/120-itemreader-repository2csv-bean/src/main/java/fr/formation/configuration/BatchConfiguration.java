package fr.formation.configuration;


import fr.formation.repository.PaysDao;
import fr.formation.repository.entity.Pays;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.data.RepositoryItemReader;
import org.springframework.batch.item.data.builder.RepositoryItemReaderBuilder;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.data.domain.Sort;

import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;


    @Autowired
    private PaysDao paysDao;

    @Bean
    public RepositoryItemReader<Pays> reader(){
        final Map<String, Sort.Direction> sorts = new HashMap<>();
        sorts.put("code", Sort.Direction.ASC);

        return new RepositoryItemReaderBuilder<Pays>()
                .name("paysReader")
                .repository(paysDao)
                .methodName("findAll")
                .sorts(sorts)
                .build();
    }

    @Bean
    public ItemProcessor<Pays, Pays> processor() {
        return pays -> {
            pays.setCapitale(pays.getCapitale() == null ? "" : pays.getCapitale().toUpperCase());
            pays.setNom(pays.getNom() == null ? "" : pays.getNom().toUpperCase());

            return pays;
        };
    }
    @Bean
    public FlatFileItemWriter<Pays> writer(){
        return new FlatFileItemWriterBuilder<Pays>()
                .name("paysItemWriter")
                .resource(new FileSystemResource("target/pays-sortie.csv"))
                .delimited()
                .names(new String[]{"code", "superficie", "capitale", "nom", "population"})
                .build();

    }

    @Bean
    public Job importPaysJob() {
        return jobBuilderFactory.get("importPaysJob")
                .start(step1())
                .build();
    }


    @Bean
    public Step step1() {
        return stepBuilderFactory.get("step1")
                .<Pays, Pays> chunk(10)
                .reader(reader())
                .processor(processor())
                .writer(writer())
                .build();
    }
}
