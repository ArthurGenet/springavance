    package fr.formation.configuration.model;


    public class Pays {
        private String name;
        private String alpha2Code;
        private String capital;
        private long population;
        private double area;

        public Pays() {
        }

        public Pays(String name, String alpha2Code, String capital, long population, double area) {
            this.name = name;
            this.alpha2Code = alpha2Code;
            this.capital = capital;
            this.population = population;
            this.area = area;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getAlpha2Code() {
            return alpha2Code;
        }

        public void setAlpha2Code(String alpha2Code) {
            this.alpha2Code = alpha2Code;
        }

        public String getCapital() {
            return capital;
        }

        public void setCapital(String capital) {
            this.capital = capital;
        }

        public long getPopulation() {
            return population;
        }

        public void setPopulation(long population) {
            this.population = population;
        }

        public double getArea() {
            return area;
        }

        public void setArea(double area) {
            this.area = area;
        }

        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder("Pays{");
            sb.append("name='").append(name).append('\'');
            sb.append(", alpha2Code='").append(alpha2Code).append('\'');
            sb.append(", capital='").append(capital).append('\'');
            sb.append(", population=").append(population);
            sb.append(", area=").append(area);
            sb.append('}');
            return sb.toString();
        }
    }
