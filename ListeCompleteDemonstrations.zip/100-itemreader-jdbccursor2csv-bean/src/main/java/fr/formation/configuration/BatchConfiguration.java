package fr.formation.configuration;


import fr.formation.configuration.model.Pays;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.jdbc.core.BeanPropertyRowMapper;

import javax.sql.DataSource;
@SuppressWarnings("all")
@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;

    @Autowired
    public DataSource dataSource;

    private static final String SELECT_ALL_PAYS = "SELECT nom as name, " +
                                                        "capitale as capital, " +
                                                        "code as alpha2code, " +
                                                        "population as population, " +
                                                        "superficie as area " +
                                                   "FROM PAYS";

    @Bean
    public JdbcCursorItemReader<Pays> reader(){
        return new JdbcCursorItemReaderBuilder<Pays>()
                .name("paysReader")
                .sql(SELECT_ALL_PAYS)
                .dataSource(dataSource)
                .rowMapper(new BeanPropertyRowMapper<>(Pays.class))
                .build();
    }

    @Bean
    public ItemProcessor<Pays, Pays> processor() {
        return pays -> {
            pays.setCapital(pays.getCapital() == null ? "" : pays.getCapital().toUpperCase());
            pays.setName(pays.getName() == null ? "" : pays.getName().toUpperCase());

            return pays;
        };
    }
    @Bean
    public FlatFileItemWriter<Pays> writer(){
        return new FlatFileItemWriterBuilder<Pays>()
                .name("paysItemWriter")
                .resource(new FileSystemResource("target/pays-sortie.csv"))
                .delimited()
                .names(new String[]{"alpha2Code", "area", "capital", "name", "population"})
                .build();

    }

    @Bean
    public Job importPaysJob() {
        return jobBuilderFactory.get("importPaysJob")
                .start(step1())
                .build();
    }


    @Bean
    public Step step1() {
        return stepBuilderFactory.get("step1")
                .<Pays, Pays> chunk(10)
                .reader(reader())
                .processor(processor())
                .writer(writer())
                .build();
    }
}
