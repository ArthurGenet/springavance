package fr.formation;

import fr.formation.config.SpringConfig;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.Collection;

public class Lancement {
    public static void main(String[] args) {

        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
        JobLauncher jobLauncher = (JobLauncher) context.getBean(JobLauncher.class);
        Job job = context.getBean(Job.class);

        System.out.println("Starting the batch job");
        try {
            JobExecution jobExecution = jobLauncher.run(job, new JobParameters());

            Collection<StepExecution> stepExecutions = jobExecution.getStepExecutions();
            stepExecutions.forEach(stepE ->
                    System.out.println("Step '" + stepE.getStepName() + "' Status : " + stepE.getStatus()));

            System.out.println("Job '" + jobExecution.getJobInstance().getJobName()+ "' Status : " + jobExecution.getStatus());
        } catch (Exception e) {
            System.out.println("Job failed : " + e.getMessage());
        }
        context.close();
    }

}
