package fr.formation.configuration;


import fr.formation.repository.PaysDao;
import fr.formation.repository.entity.Pays;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.data.RepositoryItemWriter;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.ItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.lang.Nullable;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;


    @Bean
    public FlatFileItemReader<Pays> reader(){
        return new FlatFileItemReaderBuilder<Pays>()
                .name("paysItemReader")
                .resource(new ClassPathResource("pays_init.csv"))
                .linesToSkip(1)
                .delimited()
                .names("code","superficie","capitale","nom","population")
                .fieldSetMapper(new BeanWrapperFieldSetMapper<Pays>() {{
                    setTargetType(Pays.class);
                }})
                .build();
    }

    @Bean
    public ItemProcessor<Pays, Pays> processor() {
        return pays -> pays;
    }



    @Autowired
    private PaysDao paysDao;

    @Bean
    public RepositoryItemWriter<Pays> writer() {
        RepositoryItemWriter<Pays> writer = new RepositoryItemWriter<>();
        writer.setRepository(paysDao);
        writer.setMethodName("save");
        return writer;
    }

    @Bean
    public Job importJourFerieJob() {
        return jobBuilderFactory.get("importJourFerieJob")
                .start(step1())
                .build();
    }


    @Bean
    public Step step1() {
        return stepBuilderFactory.get("step1")
                .<Pays, Pays> chunk(10)
                .reader(reader())
                .processor(processor())
                .writer(writer())
                .build();
    }

}
