package fr.formation.repository;

import fr.formation.repository.entity.Pays;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaysDao extends JpaRepository<Pays, Long> {
}
