package fr.formation.configuration;


import fr.formation.configuration.model.Finance;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.support.SynchronizedItemStreamReader;
import org.springframework.batch.item.support.SynchronizedItemStreamWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

    @Autowired
    private JobBuilderFactory jobBuilderFactory;

    @Autowired
    private StepBuilderFactory stepBuilderFactory;


    @Bean
    public FlatFileItemReader<Finance> reader() {
        System.out.println("reader ...");
        return new FlatFileItemReaderBuilder<Finance>()
                .name("itemReader")
                .resource(new ClassPathResource("finances.csv"))
                .linesToSkip(1)

                .delimited()
                .includedFields(0,3,4,6,8)
                .names("annee", "nom", "unite", "nomVariable", "valeur")
                .fieldSetMapper(new BeanWrapperFieldSetMapper<Finance>() {{
                    setTargetType(Finance.class);
                }})

                .build();
    }

    @Bean
    public ItemProcessor<Finance, Finance> processor() {
        return f -> {
            f.setNom(f.getNom().toUpperCase());
            return f;
        };
    }

    @Bean
    public FlatFileItemWriter<Finance> writer() {
        return new FlatFileItemWriterBuilder<Finance>()
                .name("paysItemWriter")
                .resource(new FileSystemResource("target/finance_sortie.csv"))
                .delimited()
                .names("annee", "nom", "unite", "nomVariable", "valeur")
                .build();
    }

    @Bean
    public TaskExecutor taskExecutor() {
        return new SimpleAsyncTaskExecutor("task");
    }
    @Bean
    public Step step() {
        return stepBuilderFactory.get("step")
                .<Finance, Finance>chunk(10)
                .reader(syncReader())
                .processor(processor())
                .writer(syncWriter())
                .allowStartIfComplete(true)
                .taskExecutor(taskExecutor())
                .build();
    }

    @Bean
    public Job job() {
        return jobBuilderFactory.get("job")
                .start(step())
                .build();
    }

    @Bean
    public SynchronizedItemStreamReader<Finance> syncReader() {
        SynchronizedItemStreamReader<Finance> synchronizedItemStreamReader = new SynchronizedItemStreamReader<>();
        synchronizedItemStreamReader.setDelegate(reader());
        return synchronizedItemStreamReader;
    }

    @Bean
    public SynchronizedItemStreamWriter<Finance> syncWriter() {
        SynchronizedItemStreamWriter<Finance> synchronizedItemStreamWriter = new SynchronizedItemStreamWriter<>();
        synchronizedItemStreamWriter.setDelegate(writer());
        return synchronizedItemStreamWriter;
    }
}
