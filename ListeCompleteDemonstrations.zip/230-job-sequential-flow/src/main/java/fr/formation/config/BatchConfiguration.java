package fr.formation.config;


import fr.formation.bo.Pays;
import fr.formation.repository.entity.PaysEntity;
import fr.formation.tasklets.DeleteUnzipFileTasklet;
import fr.formation.tasklets.ListRepositoryDataTasklet;
import fr.formation.tasklets.UnzipTasklet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.*;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.job.builder.FlowBuilder;
import org.springframework.batch.core.job.flow.Flow;
import org.springframework.batch.core.job.flow.support.SimpleFlow;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.data.RepositoryItemWriter;
import org.springframework.batch.item.json.JsonItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.net.MalformedURLException;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

    @Autowired
    private JobBuilderFactory jobBuilderFactory;

    @Autowired
    private StepBuilderFactory stepBuilderFactory;

    @Autowired
    JsonItemReader<Pays> reader;

    @Autowired
    ItemProcessor<Pays, PaysEntity> processor;

    @Autowired
    RepositoryItemWriter<PaysEntity> writer;

    @Autowired
    UnzipTasklet unzipTasklet;

    @Autowired
    DeleteUnzipFileTasklet deleteUnzipFileTasklet;

    @Autowired
    ListRepositoryDataTasklet listRepositoryDataTasklet;

    @Bean
    public Step unzipStep(){
        return stepBuilderFactory.get("unzipTasklet")
                .tasklet(unzipTasklet)
                .build();
    }

    @Bean
    public Step transfertToRepositoryStep() throws MalformedURLException {
        return stepBuilderFactory.get("chunkTransfertToRepository")
                .<Pays, PaysEntity> chunk(10)
                .reader(reader)
                .processor(processor)
                .writer(writer)
                .build();
    }


    @Bean
    public Step deleteUnzipFileStep(){
        return stepBuilderFactory.get("deleteUnzipFileTasklet")
                .tasklet(deleteUnzipFileTasklet)
                .build();
    }
    @Bean
    public Step listRepositoryDataStep(){
        return stepBuilderFactory.get("listRepositoryDataTasklet")
                .tasklet(listRepositoryDataTasklet)
                .build();
    }


    @Bean
    public Flow flowTransfertData() throws MalformedURLException {
        return new FlowBuilder<SimpleFlow>("flowTransfertData")
                .start(unzipStep())
                .next(transfertToRepositoryStep())
                .next(deleteUnzipFileStep())
                .build();
    }


    @Bean
    public Flow flowAffichageData() throws MalformedURLException {
        return new FlowBuilder<SimpleFlow>("flowTransfertData")
                .start(listRepositoryDataStep())
                .build();
    }


    @Bean
    public Job myJob() throws MalformedURLException {
        return jobBuilderFactory.get("MyJobFlow")
                .start(flowTransfertData())
                .next(flowAffichageData())
                .end()
                .build();
    }

}
