    package fr.formation.processor;

    import fr.formation.bo.Pays;
    import org.springframework.batch.item.ItemProcessor;

    public class UppercaseProcessor implements ItemProcessor<Pays, Pays> {

        @Override
        public Pays process(Pays pays) throws Exception {
            pays.setCapital(pays.getCapital().toUpperCase());
            pays.setName(pays.getName().toUpperCase());
            return pays;
        }
    }


