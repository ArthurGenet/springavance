    package fr.formation.config;

    import org.springframework.batch.item.file.FlatFileHeaderCallback;

    import java.io.IOException;
    import java.io.Writer;

    public class PaysHeaderCallback implements FlatFileHeaderCallback {
        @Override
        public void writeHeader(Writer writer) throws IOException {
            writer.write("alphacode;superficie;capitale;nom;population");
        }
    }


