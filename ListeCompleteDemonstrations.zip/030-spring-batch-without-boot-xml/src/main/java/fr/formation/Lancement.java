package fr.formation;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.HashMap;
import java.util.Map;

public class Lancement {
    public static void main(String[] args) {

        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("springbatch.xml");
        JobLauncher jobLauncher = context.getBean(JobLauncher.class);
        Job job = context.getBean(Job.class);

        // [...]

        System.out.println("Starting the batch job");
        try {
            Map<String, JobParameter> parameters = new HashMap<>();
            parameters.put("time",new JobParameter(System.nanoTime()));
            JobParameters jobParameters = new JobParameters(parameters);

            JobExecution jobExecution = jobLauncher.run(job, jobParameters);
            System.out.println("Job Status : " + jobExecution.getStatus());
            System.out.println("Job completed");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Job failed");
        }
        context.close();
    }

}
