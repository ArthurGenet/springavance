package fr.formation.config;


import fr.formation.bo.Pays;
import fr.formation.exception.PopulationException;
import fr.formation.exception.ServiceException;
import fr.formation.exception.SuperficieException;
import fr.formation.repository.PaysDao;
import fr.formation.repository.entity.PaysEntity;
import fr.formation.tasklet.VerifyDataTasklet;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.step.skip.SkipPolicy;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.data.RepositoryItemWriter;
import org.springframework.batch.item.json.JacksonJsonObjectReader;
import org.springframework.batch.item.json.JsonItemReader;
import org.springframework.batch.item.json.builder.JsonItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.retry.RetryPolicy;
import org.springframework.retry.policy.ExceptionClassifierRetryPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;

import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

@Configuration
@EnableBatchProcessing
public class PaysConfiguration {

    @Bean
    public JsonItemReader<Pays> reader() throws MalformedURLException {
        return new JsonItemReaderBuilder<Pays>()
                .name("paysItemReader")
                .resource(new ClassPathResource("pays.json"))
                .jsonObjectReader(new JacksonJsonObjectReader<>(Pays.class))

                .build();
    }

    @Bean
    public ItemProcessor<Pays, PaysEntity> processor() throws ServiceException {
        return pays -> {

            if (pays.getArea() <= 0) {
                System.out.println("PB Area : " + pays);
                throw new SuperficieException(pays.getArea(), "Superficie négative");
            }
            if (pays.getPopulation() <= 0){
                System.out.println("PB Population : " + pays);
                throw new PopulationException(pays.getPopulation(), "Population négative");
            }
            if (pays.getName() == null || pays.getName().isBlank()){
                System.out.println("PB : " + pays);
                throw new ServiceException("Nom obligatoire");
            }


            PaysEntity pe = new PaysEntity();
            pe.setCapitale(pays.getCapital());
            pe.setCode(pays.getAlpha2Code());
            pe.setNom(pays.getName());
            pe.setPopulation(pays.getPopulation());
            pe.setSuperficie(pays.getArea());


            return pe;
        };
    }




    @Autowired
    private PaysDao paysDao;

    @Bean
    public RepositoryItemWriter<PaysEntity> writer() {
        RepositoryItemWriter<PaysEntity> writer = new RepositoryItemWriter<>();
        writer.setRepository(paysDao);
        writer.setMethodName("save");
        return writer;
    }


    @Autowired
    public JobBuilderFactory jobBuilderFactory;

    @Autowired
    public StepBuilderFactory stepBuilderFactory;

    @Bean
    public Job importJourFerieJob() throws MalformedURLException, ServiceException {
        return jobBuilderFactory.get("paysJob")
                .start(step1())
                .next(step2())
                .build();
    }




    @Bean
    public Step step1() throws MalformedURLException, ServiceException {
        return stepBuilderFactory.get("step1")
                .<Pays, PaysEntity> chunk(10)
                .reader(reader())
                .processor(processor())
                .writer(writer())
                .faultTolerant()
                .skipPolicy(customSkipPolicy())
                .build();
    }




//    @Bean
//    public Step step1() throws MalformedURLException, ServiceException {
//        return stepBuilderFactory.get("step1")
//                .<Pays, PaysEntity> chunk(10)
//                .reader(reader())
//                .processor(processor())
//                .writer(writer())
//                .faultTolerant()
//                .skipLimit(13)
//                .skip(Exception.class)
//                .noSkip(PopulationException.class)
//                .build();
//    }

//
//    @Bean
//    public Step step1() throws MalformedURLException, ServiceException {
//        return stepBuilderFactory.get("step1")
//                .<Pays, PaysEntity> chunk(10)
//                .reader(reader())
//                .processor(processor())
//                .writer(writer())
//                .faultTolerant()
//                .skipLimit(13)
//                .skip(ServiceException.class)
//                .skip(PopulationException.class)
//                .skip(SuperficieException.class)
//                .build();
//    }


    @Autowired
    private VerifyDataTasklet verifyDataTasklet;


    @Bean
    public Step step2(){
        return stepBuilderFactory.get("step2")
                .tasklet(verifyDataTasklet)
                .build();
    }


    @Bean
    public SkipPolicy customSkipPolicy(){
        final int MAX_SKIP_COUNT = 30;
        AtomicInteger populationSkipCount = new AtomicInteger(5);
        AtomicInteger superficieSkipCount = new AtomicInteger(10);
        SkipPolicy sp = (throwable, skipCount) -> {
            if (skipCount > MAX_SKIP_COUNT) return false;

            if (throwable instanceof ServiceException) return false;

            if (throwable instanceof PopulationException && populationSkipCount.decrementAndGet() >= 0){
                if (((PopulationException) throwable).getPopulation() < 0 ) return false;
                else return true;
            }

            if (throwable instanceof SuperficieException && superficieSkipCount.decrementAndGet() >= 0){
                if (((SuperficieException) throwable).getSuperficie() < 0) return false;
                else return true;
            }
            return false;
        };
        return sp;
    }

}
